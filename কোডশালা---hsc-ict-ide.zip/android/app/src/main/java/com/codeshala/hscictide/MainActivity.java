package com.codeshala.hscictide;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
