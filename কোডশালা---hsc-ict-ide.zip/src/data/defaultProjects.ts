/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Project } from '../types';

export const DEFAULT_PROJECTS: Project[] = [
  // --- C Program Templates ---
  {
    id: 'c-series-sum',
    name: '১ থেকে N পর্যন্ত যোগফল (C)',
    language: 'c',
    code: `// ১ থেকে N পর্যন্ত সংখ্যার যোগফল নির্ণয়ের সি প্রোগ্রাম
#include <stdio.h>

int main() {
    int n, sum = 0, i;
    
    printf("N এর মান ইনপুট দিন: ");
    scanf("%d", &n);
    
    for(i = 1; i <= n; i++) {
        sum = sum + i;
    }
    
    printf("১ থেকে %d পর্যন্ত সংখ্যার যোগফল = %d\\n", n, sum);
    return 0;
}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },
  {
    id: 'c-largest-three',
    name: '৩টি সংখ্যার মধ্যে বড়টি (C)',
    language: 'c',
    code: `// ৩টি সংখ্যার মধ্যে বৃহত্তম সংখ্যা নির্ণয়ের সি প্রোগ্রাম
#include <stdio.h>

int main() {
    int a, b, c;
    
    printf("৩টি সংখ্যা ইনপুট দিন (স্পেস দিয়ে): ");
    scanf("%d %d %d", &a, &b, &c);
    
    if(a >= b && a >= c) {
        printf("সবচেয়ে বড় সংখ্যা = %d\\n", a);
    } else if(b >= a && b >= c) {
        printf("সবচেয়ে বড় সংখ্যা = %d\\n", b);
    } else {
        printf("সবচেয়ে বড় সংখ্যা = %d\\n", c);
    }
    
    return 0;
}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },
  {
    id: 'c-factorial',
    name: 'ফ্যাক্টোরিয়াল নির্ণয় (C)',
    language: 'c',
    code: `// লুপ ব্যবহার করে কোনো সংখ্যার ফ্যাক্টোরিয়াল নির্ণয়
#include <stdio.h>

int main() {
    int n, i;
    unsigned long long fact = 1;
    
    printf("একটি ধনাত্মক সংখ্যা ইনপুট দিন: ");
    scanf("%d", &n);
    
    if (n < 0) {
        printf("ঋণাত্মক সংখ্যার ফ্যাক্টোরিয়াল হয় না।\\n");
    } else {
        for (i = 1; i <= n; i++) {
            fact *= i;
        }
        printf("%d এর ফ্যাক্টোরিয়াল = %llu\\n", n, fact);
    }
    
    return 0;
}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },

  // --- Python Program Templates ---
  {
    id: 'py-prime-check',
    name: 'মৌলিক সংখ্যা যাচাই (Python)',
    language: 'python',
    code: `# একটি সংখ্যা মৌলিক কি না তা যাচাই করার পাইথন প্রোগ্রাম
num = int(input("একটি সংখ্যা ইনপুট দিন: "))

if num > 1:
    is_prime = True
    for i in range(2, num):
        if (num % i) == 0:
            is_prime = False
            break
            
    if is_prime:
        print(num, "একটি মৌলিক সংখ্যা")
    else:
        print(num, "মৌলিক সংখ্যা নয়")
else:
    print(num, "মৌলিক সংখ্যা নয়")
`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },
  {
    id: 'py-leap-year',
    name: 'লিপ ইয়ার বা অধিবর্ষ (Python)',
    language: 'python',
    code: `# একটি বছর অধিবর্ষ (Leap Year) কি না তা যাচাই করার প্রোগ্রাম
year = int(input("একটি সাল বা বছর লিখুন: "))

if (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0):
    print(year, "সালটি একটি লিপ ইয়ার")
else:
    print(year, "সালটি লিপ ইয়ার নয়")
`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },

  // --- SQL Templates ---
  {
    id: 'sql-student-db',
    name: 'শিক্ষার্থী তথ্য ডাটাবেজ (SQL)',
    language: 'sql',
    code: `-- শিক্ষার্থীদের তথ্য নিয়ে একটি ডাটাবেজ টেবিল তৈরি ও কুয়েরি
CREATE TABLE Students (
    Roll INT PRIMARY KEY,
    Name TEXT,
    GPA REAL,
    Group_Name TEXT
);

INSERT INTO Students VALUES (101, 'আব্দুর রহমান', 5.00, 'Science');
INSERT INTO Students VALUES (102, 'ফাতেমা আক্তার', 4.85, 'Science');
INSERT INTO Students VALUES (103, 'সাকিব আল হাসান', 4.50, 'Commerce');
INSERT INTO Students VALUES (104, 'নুসরাত জাহান', 5.00, 'Humanities');
INSERT INTO Students VALUES (105, 'তাসনিম আহমেদ', 4.20, 'Commerce');

-- জিপিএ ৫.০০ পাওয়া শিক্ষার্থীদের তালিকা দেখা যাক
SELECT Roll, Name, GPA, Group_Name FROM Students WHERE GPA = 5.00;
`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },
  {
    id: 'sql-employee-db',
    name: 'কর্মকর্তা বেতন তালিকা (SQL)',
    language: 'sql',
    code: `-- কর্মকর্তাদের বেতন হিসাবের SQL টেবিল
CREATE TABLE Employees (
    ID INT PRIMARY KEY,
    Name TEXT,
    Department TEXT,
    Salary INT
);

INSERT INTO Employees VALUES (1, 'কামাল উদ্দিন', 'IT', 45000);
INSERT INTO Employees VALUES (2, 'হাসান মাহমুদ', 'HR', 38000);
INSERT INTO Employees VALUES (3, 'রকিবুল ইসলাম', 'IT', 52000);
INSERT INTO Employees VALUES (4, 'শায়লা শারমিন', 'Finance', 48000);
INSERT INTO Employees VALUES (5, 'জাহিদ হাসান', 'Admin', 35000);

-- আইটি বিভাগের কর্মকর্তাদের বেতন ক্রমানুসারে (উচ্চ থেকে নিম্ন)
SELECT ID, Name, Department, Salary FROM Employees 
WHERE Department = 'IT' 
ORDER BY Salary DESC;
`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },

  // --- HTML / CSS / JS Templates ---
  {
    id: 'html-table-demo',
    name: 'এইচটিএমএল টেবিল ডিজাইন (HTML)',
    language: 'html',
    code: `<!DOCTYPE html>
<html>
<head>
    <title>এইচটিএমএল টেবিল উদাহরণ</title>
    <style>
        body {
            font-family: 'SolaimanLipi', Arial, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            padding: 20px;
        }
        h2 {
            color: #4F7DF7;
            text-align: center;
        }
        table {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            text-align: center;
            border: 1px solid #ddd;
        }
        th {
            background-color: #4F7DF7;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .highlight {
            font-weight: bold;
            color: #2e7d32;
        }
    </style>
</head>
<body>

    <h2>এইচএসসি ২০২৬ পরীক্ষার রেজাল্ট শিট</h2>
    
    <table>
        <thead>
            <tr>
                <th>রোল</th>
                <th>নাম</th>
                <th>আইসিটি মার্ক্স</th>
                <th>গ্রেড</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>১০১</td>
                <td>শাহাদাত হোসাইন</td>
                <td>৯৫</td>
                <td class="highlight">A+</td>
            </tr>
            <tr>
                <td>১০২</td>
                <td>সাকিব আল হাসান</td>
                <td>৮৮</td>
                <td class="highlight">A+</td>
            </tr>
            <tr>
                <td>১০৩</td>
                <td>ফাতেমা আক্তার</td>
                <td>৭২</td>
                <td>A</td>
            </tr>
            <tr>
                <td>১০৪</td>
                <td>আব্দুর রহমান</td>
                <td>৫৩</td>
                <td>B</td>
            </tr>
        </tbody>
    </table>

    <p style="text-align: center; font-size: 13px; color: #777;">
        * Note: This is Chapter 4 (Web Design & HTML) tutorial of HSC ICT.
    </p>

</body>
</html>`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  },
  {
    id: 'html-calculator',
    name: 'সহজ ক্যালকুলেটর (HTML/CSS/JS)',
    language: 'html',
    code: `<!DOCTYPE html>
<html>
<head>
    <title>ইন্টারেক্টিভ ক্যালকুলেটর</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #e0eafc, #cfdef3);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
            margin: 0;
        }
        .calculator {
            background-color: #fff;
            padding: 20px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 280px;
        }
        #display {
            width: 100%;
            height: 50px;
            background-color: #f4f6f9;
            border: none;
            outline: none;
            border-radius: 8px;
            font-size: 20px;
            text-align: right;
            padding: 10px;
            box-sizing: border-box;
            margin-bottom: 20px;
            color: #333;
        }
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        button {
            padding: 15px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            background-color: #f1f3f6;
            cursor: pointer;
            transition: background 0.2s;
        }
        button:hover {
            background-color: #e4e7eb;
        }
        button.operator {
            background-color: #4F7DF7;
            color: white;
        }
        button.operator:hover {
            background-color: #3d6ae5;
        }
        button.clear {
            background-color: #ea4335;
            color: white;
        }
        button.clear:hover {
            background-color: #d33225;
        }
        button.equal {
            background-color: #34a853;
            color: white;
            grid-column: span 2;
        }
        button.equal:hover {
            background-color: #2b8c44;
        }
    </style>
</head>
<body>

<div class="calculator">
    <input type="text" id="display" readonly placeholder="0">
    <div class="buttons">
        <button class="clear" onclick="clearDisplay()">C</button>
        <button onclick="appendValue('/')" class="operator">/</button>
        <button onclick="appendValue('*')" class="operator">*</button>
        <button onclick="appendValue('-')" class="operator">-</button>
        
        <button onclick="appendValue('7')">7</button>
        <button onclick="appendValue('8')">8</button>
        <button onclick="appendValue('9')">9</button>
        <button onclick="appendValue('+')" class="operator">+</button>
        
        <button onclick="appendValue('4')">4</button>
        <button onclick="appendValue('5')">5</button>
        <button onclick="appendValue('6')">6</button>
        <button class="equal" onclick="calculate()">=</button>
        
        <button onclick="appendValue('1')">1</button>
        <button onclick="appendValue('2')">2</button>
        <button onclick="appendValue('3')">3</button>
        <button onclick="appendValue('0')" style="grid-column: span 2;">0</button>
        <button onclick="appendValue('.')">.</button>
    </div>
</div>

<script>
    const display = document.getElementById('display');

    function appendValue(val) {
        if (display.value === '0') {
            display.value = val;
        } else {
            display.value += val;
        }
    }

    function clearDisplay() {
        display.value = '';
    }

    function calculate() {
        try {
            display.value = eval(display.value);
        } catch (error) {
            display.value = 'Error';
        }
    }
</script>

</body>
</html>`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isArchived: false,
  }
];
