/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Terminal, 
  Settings as SettingsIcon, 
  Folder, 
  BookOpen, 
  Code, 
  Sparkles, 
  HelpCircle,
  X,
  Smartphone,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { Project, Settings, Language, CompilerResult } from './types';
import { DEFAULT_PROJECTS } from './data/defaultProjects';
import { CInterpreter } from './services/cInterpreter';
import { PythonInterpreter } from './services/pythonInterpreter';
import { SQLEngine } from './services/sqlEngine';

import Dashboard from './components/Dashboard';
import EditorView from './components/EditorView';
import OutputBottomSheet from './components/OutputBottomSheet';
import SettingsView from './components/SettingsView';

export default function App() {
  // --- States ---
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'settings'>('dashboard');

  const [settings, setSettings] = useState<Settings>({
    theme: 'system',
    editorTheme: 'one-dark',
    fontSize: 14,
    autoSave: true,
    language: 'bn'
  });

  // Compiler state
  const [compilerResult, setCompilerResult] = useState<CompilerResult | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);
  const [isOutputOpen, setIsOutputOpen] = useState(false);

  // Interactive Scanf/Input Modal States
  const [inputPrompt, setInputPrompt] = useState<string | null>(null);
  const [inputValue, setInputValue] = useState('');
  const [inputResolve, setInputResolve] = useState<((val: string) => void) | null>(null);

  // --- Initializers & LocalStorage Persistence ---
  useEffect(() => {
    // 1. Load Settings
    const savedSettingsStr = localStorage.getItem('codeshala_settings');
    if (savedSettingsStr) {
      try {
        setSettings(JSON.parse(savedSettingsStr));
      } catch (e) {}
    }

    // 2. Load Projects
    const savedProjectsStr = localStorage.getItem('codeshala_projects');
    if (savedProjectsStr) {
      try {
        const loaded: Project[] = JSON.parse(savedProjectsStr);
        if (loaded && loaded.length > 0) {
          setProjects(loaded);
          return;
        }
      } catch (e) {}
    }
    // Fallback default starter projects if none exist
    setProjects(DEFAULT_PROJECTS);
    localStorage.setItem('codeshala_projects', JSON.stringify(DEFAULT_PROJECTS));
  }, []);

  // Save projects on update
  const saveProjectsToStorage = (updatedProjects: Project[]) => {
    setProjects(updatedProjects);
    localStorage.setItem('codeshala_projects', JSON.stringify(updatedProjects));
  };

  // Save settings on update
  const handleUpdateSettings = (newSettings: Settings) => {
    setSettings(newSettings);
    localStorage.setItem('codeshala_settings', JSON.stringify(newSettings));
  };

  // --- Theme Controller ---
  useEffect(() => {
    const root = window.document.documentElement;
    const updateTheme = () => {
      const isDark = 
        settings.theme === 'dark' || 
        (settings.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
      
      if (isDark) {
        root.classList.add('dark');
        root.style.backgroundColor = '#090909';
      } else {
        root.classList.remove('dark');
        root.style.backgroundColor = '#FAFAFC';
      }
    };

    updateTheme();
    // Watch system changes if on 'system' setting
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    mediaQuery.addEventListener('change', updateTheme);
    return () => mediaQuery.removeEventListener('change', updateTheme);
  }, [settings.theme]);

  // --- Project Management Actions ---
  const handleCreateProject = (name: string, language: Language, initialCode: string = '') => {
    const newProj: Project = {
      id: `proj-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name,
      language,
      code: initialCode,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isArchived: false
    };

    const updated = [newProj, ...projects];
    saveProjectsToStorage(updated);
    setActiveProjectId(newProj.id); // open editor right away
  };

  const handleUpdateProjectCode = (updatedCode: string) => {
    if (!activeProjectId) return;
    const updated = projects.map(p => {
      if (p.id === activeProjectId) {
        return {
          ...p,
          code: updatedCode,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });
    saveProjectsToStorage(updated);
  };

  const handleDeleteProject = (id: string) => {
    const updated = projects.filter(p => p.id !== id);
    saveProjectsToStorage(updated);
    if (activeProjectId === id) {
      setActiveProjectId(null);
    }
  };

  const handleRenameProject = (id: string, newName: string) => {
    if (!newName.trim()) return;
    const updated = projects.map(p => {
      if (p.id === id) {
        return {
          ...p,
          name: newName,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });
    saveProjectsToStorage(updated);
  };

  const handleDuplicateProject = (id: string) => {
    const original = projects.find(p => p.id === id);
    if (!original) return;

    const copy: Project = {
      ...original,
      id: `proj-copy-${Date.now()}`,
      name: `${original.name} (কপি)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updated = [copy, ...projects];
    saveProjectsToStorage(updated);
  };

  const handleArchiveProject = (id: string) => {
    const updated = projects.map(p => {
      if (p.id === id) {
        return {
          ...p,
          isArchived: !p.isArchived,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });
    saveProjectsToStorage(updated);
  };

  const handleImportBackup = (backupStr: string) => {
    try {
      const imported: Project[] = JSON.parse(backupStr);
      if (Array.isArray(imported)) {
        // Simple merge
        const merged = [...imported, ...projects];
        // Unique elements filter by ID
        const unique = merged.filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);
        saveProjectsToStorage(unique);
        alert(`সবগুলো প্রজেক্ট সফলভাবে ইম্পোর্ট করা হয়েছে!`);
      } else {
        alert(`ত্রুটি: ফাইলটি সঠিক কোডশালা ফাইল নয়।`);
      }
    } catch (e) {
      alert(`ব্যাকআপ ফাইলটি পড়তে ব্যর্থ হয়েছে। ফাইল ফরম্যাট চেক করুন।`);
    }
  };

  // --- Async Interactive Input Resolver ---
  const handleRequestInput = (promptMsg: string): Promise<string> => {
    return new Promise<string>((resolve) => {
      setInputPrompt(promptMsg || "ইনপুট লিখুন:");
      setInputValue('');
      setInputResolve(() => resolve);
    });
  };

  const handleSubmitInput = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputResolve) {
      inputResolve(inputValue);
      setInputResolve(null);
      setInputPrompt(null);
    }
  };

  // --- COMPILER RUNNER IMPLEMENTATION ---
  const handleRunCode = async (codeToRun: string): Promise<CompilerResult> => {
    setIsCompiling(true);
    setCompilerResult(null);

    const activeProject = projects.find(p => p.id === activeProjectId);
    if (!activeProject) {
      setIsCompiling(false);
      return { success: false, output: 'ত্রুটি: প্রজেক্ট খুঁজে পাওয়া যায়নি।', logs: [] };
    }

    try {
      // Small artificial delay to show compiler progress beautifully
      await new Promise(resolve => setTimeout(resolve, 800));

      let result: CompilerResult;

      if (activeProject.language === 'c') {
        const interpreter = new CInterpreter(handleRequestInput);
        result = await interpreter.run(codeToRun);
      } else if (activeProject.language === 'python') {
        const interpreter = new PythonInterpreter(handleRequestInput);
        result = await interpreter.run(codeToRun);
      } else if (activeProject.language === 'sql') {
        const engine = new SQLEngine();
        result = engine.execute(codeToRun);
      } else if (activeProject.language === 'html') {
        result = {
          success: true,
          output: "এইচটিএমএল পেজটি সফলভাবে প্রস্তুত করা হয়েছে! নিচে লাইভ প্রিভিউ দেখতে পাবেন।",
          logs: [
            { type: 'success', message: 'HTML/CSS/JS কোড পার্স সম্পন্ন হয়েছে।' },
            { type: 'info', message: 'লাইভ ওয়েব পেজ রেন্ডার করা হয়েছে।' }
          ],
          htmlCode: codeToRun
        };
      } else {
        throw new Error("Unsupported language runner");
      }

      setCompilerResult(result);
      setIsCompiling(false);
      return result;

    } catch (err: any) {
      setIsCompiling(false);
      const res = {
        success: false,
        output: err.message || String(err),
        logs: [{ type: 'error' as const, message: `রান ব্যর্থ: ${err.message || err}` }]
      };
      setCompilerResult(res);
      return res;
    }
  };

  // Find active project item
  const currentProject = useMemo(() => {
    return projects.find(p => p.id === activeProjectId) || null;
  }, [projects, activeProjectId]);

  return (
    <div className={`min-h-screen ${currentProject ? 'h-screen md:h-screen overflow-hidden' : ''} bg-[#fafafc] text-gray-800 dark:bg-[#090909] dark:text-gray-100 flex flex-col font-sans transition-colors duration-300`}>
      
      {/* Dynamic Render Mode: Editor View vs Full Frame Dashboard */}
      {currentProject ? (
        <EditorView
          project={currentProject}
          settings={settings}
          onUpdateCode={handleUpdateProjectCode}
          onRunCode={handleRunCode}
          onBackToDashboard={() => {
            setActiveProjectId(null);
            setCompilerResult(null);
            setIsOutputOpen(false);
          }}
          onOpenOutputPanel={(res) => {
            setCompilerResult(res);
            setIsOutputOpen(true);
          }}
          isCompiling={isCompiling}
        />
      ) : (
        <>
          {/* Main Workspace Navigation Header */}
          <header className="sticky top-0 z-30 bg-white/85 dark:bg-[#151515]/90 border-b border-gray-100 dark:border-gray-800 backdrop-blur-md px-4 py-4.5 shrink-0 shadow-[0_1px_5px_rgba(0,0,0,0.01)]">
            <div className="max-w-4xl mx-auto flex items-center justify-between">
              {/* App Identity */}
              <div className="flex items-center gap-2.5">
                <div className="h-10 w-10 rounded-2xl bg-[#4F7DF7] flex items-center justify-center text-white shadow-md dark:bg-[#6EA8FE] dark:text-[#090909]">
                  <Terminal className="h-5.5 w-5.5 stroke-[2.5]" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="font-extrabold text-base tracking-tight text-gray-900 dark:text-white font-sans leading-none">কোডশালা</span>
                  <span className="text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase mt-1 tracking-wider leading-none">HSC ICT OFFLINE IDE</span>
                </div>
              </div>

              {/* Tab Navigation Menu */}
              <nav className="flex bg-gray-100 dark:bg-gray-800 rounded-xl p-0.5 text-xs font-semibold">
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all cursor-pointer ${activeTab === 'dashboard' ? 'bg-white dark:bg-[#151515] text-[#4F7DF7] dark:text-[#6EA8FE] shadow-sm' : 'text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white'}`}
                  id="tab-dashboard-btn"
                >
                  <Folder className="h-4.5 w-4.5" />
                  <span>ড্যাশবোর্ড</span>
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all cursor-pointer ${activeTab === 'settings' ? 'bg-white dark:bg-[#151515] text-[#4F7DF7] dark:text-[#6EA8FE] shadow-sm' : 'text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white'}`}
                  id="tab-settings-btn"
                >
                  <SettingsIcon className="h-4.5 w-4.5" />
                  <span>সেটিংস</span>
                </button>
              </nav>
            </div>
          </header>

          {/* Main Body View */}
          <main className="flex-1 overflow-y-auto px-4 py-6">
            <div className="max-w-4xl mx-auto">
              <AnimatePresence mode="wait">
                {activeTab === 'dashboard' ? (
                  <motion.div
                    key="dashboard-tab"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                  >
                    <Dashboard
                      projects={projects}
                      onCreateProject={handleCreateProject}
                      onSelectProject={(id) => setActiveProjectId(id)}
                      onDeleteProject={handleDeleteProject}
                      onRenameProject={handleRenameProject}
                      onDuplicateProject={handleDuplicateProject}
                      onArchiveProject={handleArchiveProject}
                      onImportBackup={handleImportBackup}
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="settings-tab"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                  >
                    <SettingsView
                      settings={settings}
                      onUpdateSettings={handleUpdateSettings}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </main>
        </>
      )}

      {/* --- Global Draggable Terminal Panel Sheet --- */}
      <OutputBottomSheet
        isOpen={isOutputOpen}
        onClose={() => setIsOutputOpen(false)}
        result={compilerResult}
        onClearOutput={() => setCompilerResult(null)}
      />

      {/* --- Asynchronous Interactive Input prompt (Scanf / Input Overlay dialog) --- */}
      <AnimatePresence>
        {inputPrompt !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-[#090909]"
              id="input-prompt-backdrop"
            />

            {/* Prompt Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-sm rounded-[24px] bg-white p-6 shadow-2xl dark:bg-[#151515] border border-gray-100 dark:border-gray-800 text-left z-10 font-sans"
              id="input-prompt-container"
            >
              <div className="flex items-center gap-2 mb-3">
                <Smartphone className="h-5 w-5 text-[#4F7DF7] dark:text-[#6EA8FE]" />
                <h4 className="text-sm font-extrabold text-gray-900 dark:text-white">প্রোগ্রাম ইনপুট প্রয়োজন</h4>
              </div>

              <p className="text-xs text-gray-500 dark:text-gray-400 mb-4 bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl border border-gray-100 dark:border-gray-800">
                {inputPrompt}
              </p>

              <form onSubmit={handleSubmitInput} className="space-y-3">
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="আপনার ইনপুট মান লিখুন..."
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 dark:bg-[#1E1E1E] dark:border-gray-800 rounded-xl text-sm focus:outline-none focus:border-[#4F7DF7] dark:focus:border-[#6EA8FE] text-gray-900 dark:text-white"
                  id="program-input-field"
                />

                <div className="flex gap-2 pt-1.5">
                  <button
                    type="submit"
                    className="flex-1 rounded-xl bg-[#4F7DF7] py-3 text-xs font-bold text-white hover:bg-opacity-90 dark:bg-[#6EA8FE] dark:text-[#090909] transition-colors cursor-pointer"
                    id="submit-program-input-btn"
                  >
                    ইনপুট সাবমিট করুন
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
