/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CompilerResult } from '../types';
import { parseCompilerError } from './errorParser';

export class PythonInterpreter {
  private output: string = '';
  private logs: CompilerResult['logs'] = [];
  private inputQueue: string[] = [];
  private inputCallback: ((promptMsg: string) => Promise<string>) | null = null;

  constructor(inputCallback?: (promptMsg: string) => Promise<string>) {
    if (inputCallback) {
      this.inputCallback = inputCallback;
    }
  }

  async run(code: string, providedInputs: string[] = []): Promise<CompilerResult> {
    this.output = '';
    this.logs = [];
    this.inputQueue = [...providedInputs];

    // Simple Pre-run check for indentation errors
    const indentCheckResult = this.checkIndentation(code);
    if (indentCheckResult) {
      const translated = parseCompilerError("IndentationError", 'python');
      return {
        success: false,
        output: this.output,
        logs: [
          { type: 'error', message: `লাইন ${indentCheckResult.line}: ${translated.title}` },
          { type: 'error', message: `${translated.explanation}` },
          { type: 'info', message: `${translated.suggestion}` }
        ]
      };
    }

    try {
      // Transpile Python to JS
      const transpiledJS = this.transpile(code);

      // Console logging
      const print_helper = (...args: any[]) => {
        const formatted = args.map(arg => {
          if (arg === true) return 'True';
          if (arg === false) return 'False';
          if (arg === null || arg === undefined) return 'None';
          return String(arg);
        }).join(' ');
        this.output += formatted + '\n';
      };

      // Input reading
      const input_helper = async (promptMsg: string): Promise<string> => {
        if (this.inputQueue.length > 0) {
          return this.inputQueue.shift()!;
        }
        if (this.inputCallback) {
          this.logs.push({ type: 'info', message: `ইনপুট চাওয়া হচ্ছে: ${promptMsg || 'input'}` });
          return await this.inputCallback(promptMsg || 'input');
        }
        return "0";
      };

      // Math and standard conversions
      const int = (v: any) => {
        const parsed = parseInt(v, 10);
        if (isNaN(parsed)) throw new Error(`ValueError: invalid literal for int() with value: '${v}'`);
        return parsed;
      };

      const float = (v: any) => {
        const parsed = parseFloat(v);
        if (isNaN(parsed)) throw new Error(`ValueError: invalid literal for float() with value: '${v}'`);
        return parsed;
      };

      const str = (v: any) => String(v);
      const len = (v: any) => {
        if (v && typeof v.length === 'number') return v.length;
        throw new Error(`TypeError: object of type '${typeof v}' has no len()`);
      };

      // Range helper
      const range = (startOrEnd: number, end?: number, step: number = 1): number[] => {
        let start = 0;
        let limit = startOrEnd;
        if (end !== undefined) {
          start = startOrEnd;
          limit = end;
        }
        const result: number[] = [];
        if (step > 0) {
          for (let i = start; i < limit; i += step) result.push(i);
        } else if (step < 0) {
          for (let i = start; i > limit; i += step) result.push(i);
        }
        return result;
      };

      // Run evaluation sandbox
      const runner = new Function(
        'print', 'input', 'int', 'float', 'str', 'len', 'range',
        `return (async () => {
          let __loop_count = 0;
          const __guardLoop = () => {
            if (++__loop_count > 20000) {
              throw new Error("অসীম লুপ (Infinite Loop) শনাক্ত হয়েছে! লুপটি বন্ধ করতে সঠিক কন্ডিশন ব্যবহার করুন।");
            }
          };
          ${transpiledJS}
        })();`
      );

      await runner(print_helper, input_helper, int, float, str, len, range);

      this.logs.push({ type: 'success', message: 'কোড সফলভাবে সম্পন্ন হয়েছে।' });
      return {
        success: true,
        output: this.output,
        logs: this.logs
      };

    } catch (err: any) {
      const errMsg = err.message || String(err);
      const translated = parseCompilerError(errMsg, 'python');

      this.logs.push({ type: 'error', message: `রানটাইম ত্রুটি: ${translated.title}` });
      this.logs.push({ type: 'error', message: `${translated.explanation}` });
      if (translated.suggestion) {
        this.logs.push({ type: 'info', message: `${translated.suggestion}` });
      }

      return {
        success: false,
        output: this.output,
        logs: this.logs
      };
    }
  }

  /**
   * Verify Python indentation and find obvious syntax problems
   */
  private checkIndentation(code: string): { line: number } | null {
    const lines = code.split('\n');
    let prevIndent = 0;
    const indentStack = [0];

    for (let i = 0; i < lines.length; i++) {
      const lineClean = lines[i].trim();
      if (lineClean === '' || lineClean.startsWith('#')) {
        continue;
      }

      // Calculate leading spaces
      const indentMatch = lines[i].match(/^ */);
      const indent = indentMatch ? indentMatch[0].length : 0;

      if (indent > prevIndent) {
        // Indent increased
        const lastLineClean = i > 0 ? lines[i - 1].trim() : '';
        if (lastLineClean !== '' && !lastLineClean.endsWith(':')) {
          // Indent increased without colon
          return { line: i + 1 };
        }
        indentStack.push(indent);
      } else if (indent < prevIndent) {
        // Indent decreased, must match one of previous levels
        while (indentStack.length > 0 && indentStack[indentStack.length - 1] > indent) {
          indentStack.pop();
        }
        if (indentStack[indentStack.length - 1] !== indent) {
          // Indentation doesn't match any outer block
          return { line: i + 1 };
        }
      }

      prevIndent = indent;
    }

    return null;
  }

  /**
   * Transpile Python to JS via block indentation tracking
   */
  private transpile(code: string): string {
    let js = '';
    const lines = code.split('\n');
    const indentStack: number[] = [0];
    
    for (let i = 0; i < lines.length; i++) {
      let lineRaw = lines[i];
      let lineClean = lineRaw.trim();

      if (lineClean === '' || lineClean.startsWith('#')) {
        js += '\n';
        continue;
      }

      // Calculate current line indent
      const indentMatch = lineRaw.match(/^ */);
      const indent = indentMatch ? indentMatch[0].length : 0;

      // Unindent blocks
      while (indentStack.length > 0 && indentStack[indentStack.length - 1] > indent) {
        indentStack.pop();
        js += '}\n'; // Close blocks
      }

      // Convert simple python prints
      // print("sum =", x) -> print("sum =", x)
      // JS function print is bound as helper, so it works directly

      // Convert variables or statements
      // inputs: num = int(input("...")) -> let num = int(await input("..."))
      if (lineClean.includes('input(')) {
        lineClean = lineClean.replace(/input\s*\(([^)]*)\)/g, 'await input($1)');
      }

      // If assigning variable for the first time, make it let
      // E.g. `num = 10` -> `let num = 10`
      // For simple student codes, we can check if it contains a variable declaration.
      // But we can just use global state or direct assignments:
      // In JS, variables assigned without let/var become global if not in strict mode, 
      // but in our Function sandbox, declaring them makes it cleaner.
      // Let's prepend "let " if there's a variable assignment `x = 5` and it hasn't been declared,
      // or we can initialize variables on the fly.
      // To keep it simple and robust, we can declare a set of variables or simply compile `x = 5` to `let x = 5`
      // if it's the first assignment of that variable name in the line.
      const assignMatch = lineClean.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*=[^=]/);
      if (assignMatch) {
        const varName = assignMatch[1];
        if (varName !== 'print' && varName !== 'int' && varName !== 'float' && varName !== 'str' && varName !== 'len' && varName !== 'range') {
          // Let's define the variable using let to make it local, or declare at top.
          // To support updates across scopes, compiling it to `var x = 5` or let is fine,
          // but if it's already declared, don't declare it again. 
          // An easy way is to strip the let and declare all discovered variables at the top of the script!
          // We can compile it to `var x = 5;` which is function-scoped in JS and handles re-declarations gracefully.
          lineClean = lineClean.replace(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*=/, 'var $1 =');
        }
      }

      // Map Python standard loop: for i in range(...):
      // for i in range(1, 10):
      if (lineClean.startsWith('for ') && lineClean.endsWith(':')) {
        const forMatch = lineClean.match(/^for\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+in\s+range\s*\(([^)]+)\)\s*:/);
        if (forMatch) {
          const iterVar = forMatch[1];
          const rangeArgs = forMatch[2];
          lineClean = `for (let ${iterVar} of range(${rangeArgs})) { __guardLoop();`;
          indentStack.push(indent);
        } else {
          // General list iterator: for item in list:
          const listMatch = lineClean.match(/^for\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+in\s+([^:]+)\s*:/);
          if (listMatch) {
            const iterVar = listMatch[1];
            const listVar = listMatch[2];
            lineClean = `for (let ${iterVar} of ${listVar}) { __guardLoop();`;
            indentStack.push(indent);
          }
        }
      }
      // While loop: while x < 10:
      else if (lineClean.startsWith('while ') && lineClean.endsWith(':')) {
        const cond = lineClean.substring(6, lineClean.length - 1);
        // Replace Python and/or/not in condition
        const jsCond = cond.replace(/\band\b/g, '&&').replace(/\bor\b/g, '||').replace(/\bnot\b/g, '!');
        lineClean = `while (${jsCond}) { __guardLoop();`;
        indentStack.push(indent);
      }
      // If condition: if x > 5:
      else if (lineClean.startsWith('if ') && lineClean.endsWith(':')) {
        const cond = lineClean.substring(3, lineClean.length - 1);
        const jsCond = cond.replace(/\band\b/g, '&&').replace(/\bor\b/g, '||').replace(/\bnot\b/g, '!');
        lineClean = `if (${jsCond}) {`;
        indentStack.push(indent);
      }
      // Elif condition: elif x == 5:
      else if (lineClean.startsWith('elif ') && lineClean.endsWith(':')) {
        const cond = lineClean.substring(5, lineClean.length - 1);
        const jsCond = cond.replace(/\band\b/g, '&&').replace(/\bor\b/g, '||').replace(/\bnot\b/g, '!');
        lineClean = `else if (${jsCond}) {`;
        indentStack.push(indent);
      }
      // Else condition: else:
      else if (lineClean.startsWith('else') && lineClean.endsWith(':')) {
        lineClean = `else {`;
        indentStack.push(indent);
      }

      // Convert standard Boolean and logical terms in standard statements
      lineClean = lineClean
        .replace(/\bTrue\b/g, 'true')
        .replace(/\bFalse\b/g, 'false')
        .replace(/\bNone\b/g, 'null')
        .replace(/\band\b/g, '&&')
        .replace(/\bor\b/g, '||')
        .replace(/\bnot\b/g, '!');

      // Add semicolons to assignments / simple calls
      if (!lineClean.endsWith('{') && !lineClean.endsWith('}')) {
        lineClean += ';';
      }

      // Restore indent spaces
      js += ' '.repeat(indent) + lineClean + '\n';
    }

    // Close any remaining open indentation blocks
    while (indentStack.length > 1) {
      indentStack.pop();
      js += '}\n';
    }

    return js;
  }
}
