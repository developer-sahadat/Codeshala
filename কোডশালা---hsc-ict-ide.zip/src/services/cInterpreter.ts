/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CompilerResult } from '../types';
import { parseCompilerError } from './errorParser';

export class CInterpreter {
  private output: string = '';
  private logs: CompilerResult['logs'] = [];
  private variables: Record<string, any> = {};
  private inputQueue: string[] = [];
  private inputCallback: ((promptMsg: string) => Promise<string>) | null = null;

  constructor(inputCallback?: (promptMsg: string) => Promise<string>) {
    if (inputCallback) {
      this.inputCallback = inputCallback;
    }
  }

  /**
   * Run C code asynchronously
   */
  async run(code: string, providedInputs: string[] = []): Promise<CompilerResult> {
    this.output = '';
    this.logs = [];
    this.variables = {};
    this.inputQueue = [...providedInputs];

    // Pre-execution Syntax Check (Semicolon & brackets)
    const syntaxError = this.preCheckSyntax(code);
    if (syntaxError) {
      const translated = parseCompilerError(syntaxError.message, 'c');
      return {
        success: false,
        output: this.output,
        logs: [
          { type: 'error', message: `লাইন ${syntaxError.line}: ${translated.title}` },
          { type: 'error', message: `${translated.explanation}` },
          { type: 'info', message: `${translated.suggestion}` }
        ]
      };
    }

    try {
      // Transpile C to JS
      const transpiledJS = this.transpile(code);

      // Create environment bindings
      const consoleLog = (msg: string) => {
        this.output += msg;
      };

      const readInput = async (promptMsg: string): Promise<string> => {
        if (this.inputQueue.length > 0) {
          return this.inputQueue.shift()!;
        }
        if (this.inputCallback) {
          this.logs.push({ type: 'info', message: `ইনপুট চাওয়া হচ্ছে: ${promptMsg || 'scanf'}` });
          return await this.inputCallback(promptMsg || 'scanf');
        }
        // Fallback default input
        return "0";
      };

      const printf_helper = (format: string, ...args: any[]) => {
        let result = format;
        // Strip escaped newlines to make representation clean
        result = result.replace(/\\n/g, '\n');
        result = result.replace(/\\t/g, '\t');

        // Regex for placeholders
        const placeholderRegex = /%[d|f|s|c|llu|lf]/g;
        let argIndex = 0;
        
        result = result.replace(placeholderRegex, (match) => {
          if (argIndex < args.length) {
            let val = args[argIndex++];
            if (match === '%f' || match === '%lf') {
              // limit decimal points for float
              return typeof val === 'number' ? val.toFixed(2) : val;
            }
            return String(val);
          }
          return match;
        });

        consoleLog(result);
      };

      // Math library bindings
      const sqrt = (n: number) => Math.sqrt(n);
      const pow = (base: number, exp: number) => Math.pow(base, exp);
      const abs = (n: number) => Math.abs(n);

      // Construct and execute the runner
      // We wrap it in an async function inside a sandbox
      const runner = new Function(
        'printf', 'scanf', 'sqrt', 'pow', 'abs',
        `return (async () => {
          let __loop_count = 0;
          const __guardLoop = () => {
            if (++__loop_count > 20000) {
              throw new Error("অসীম লুপ (Infinite Loop) শনাক্ত হয়েছে! লুপটি বন্ধ করতে সঠিক কন্ডিশন ব্যবহার করুন।");
            }
          };
          ${transpiledJS}
        })();`
      );

      // Wait for execution to finish
      await runner(printf_helper, readInput, sqrt, pow, abs);

      this.logs.push({ type: 'success', message: 'কোড সফলভাবে সম্পন্ন হয়েছে।' });
      return {
        success: true,
        output: this.output,
        logs: this.logs
      };

    } catch (err: any) {
      const errMsg = err.message || String(err);
      const translated = parseCompilerError(errMsg, 'c');
      
      this.logs.push({ type: 'error', message: `রানটাইম ত্রুটি: ${translated.title}` });
      this.logs.push({ type: 'error', message: `${translated.explanation}` });
      if (translated.suggestion) {
        this.logs.push({ type: 'info', message: `${translated.suggestion}` });
      }

      return {
        success: false,
        output: this.output,
        logs: this.logs
      };
    }
  }

  /**
   * Pre-execution basic syntax checker to find obvious compiler errors early
   */
  private preCheckSyntax(code: string): { message: string; line: number } | null {
    const lines = code.split('\n');
    let openBraces = 0;
    let openParentheses = 0;

    for (let i = 0; i < lines.length; i++) {
      const lineNum = i + 1;
      const lineClean = lines[i].trim();

      // Skip empty, comments, and preprocessor directives
      if (lineClean === '' || lineClean.startsWith('//') || lineClean.startsWith('#') || lineClean.startsWith('/*')) {
        continue;
      }

      // Track braces
      for (const char of lineClean) {
        if (char === '{') openBraces++;
        if (char === '}') openBraces--;
        if (char === '(') openParentheses++;
        if (char === ')') openParentheses--;
      }

      // Semicolon check
      // Semicolons are expected at the end of lines unless they end with braces,
      // are preprocessor statements, function declarations, if/for/while loops
      const isControlStatement = 
        lineClean.endsWith('{') || 
        lineClean.endsWith('}') || 
        lineClean.endsWith(';') ||
        lineClean.startsWith('if') || 
        lineClean.startsWith('else') || 
        lineClean.startsWith('for') || 
        lineClean.startsWith('while') || 
        lineClean.startsWith('int main') || 
        lineClean.startsWith('void main') ||
        lineClean.startsWith('switch') ||
        lineClean.startsWith('case') ||
        lineClean.startsWith('default:') ||
        lineClean.startsWith('//') ||
        lineClean.includes('/*');

      if (!isControlStatement && openBraces > 0) {
        // If inside a function (openBraces > 0) and doesn't end with a semicolon
        return {
          message: "expected ';'",
          line: lineNum
        };
      }
    }

    if (openBraces > 0) {
      return { message: "expected '}'", line: lines.length };
    }
    if (openParentheses > 0) {
      return { message: "expected ')'", line: lines.length };
    }

    return null;
  }

  /**
   * Transpile simplified C syntax to runnable JS
   */
  private transpile(code: string): string {
    let js = '';
    const lines = code.split('\n');

    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];

      // Remove comments
      line = line.replace(/\/\/.*$/, '');

      // Handle #include and main headers (ignore them)
      if (line.trim().startsWith('#include') || /int\s+main\s*\(/.test(line) || /void\s+main\s*\(/.test(line)) {
        continue;
      }

      // Handle return 0;
      if (line.includes('return 0;')) {
        line = line.replace('return 0;', 'return;');
      }

      // Translate standard variable types:
      // int a, b = 5, c; -> let a = 0, b = 5, c = 0;
      if (/^\s*(int|float|double|char|unsigned|long)\s+/.test(line)) {
        line = line.replace(/^\s*(int|float|double|char|unsigned|long|long long)\s+/, (match) => {
          return ' let ';
        });
        
        // Ensure uninitialized variables get 0/null in JS rather than undefined
        // Find variable declarations (simple match)
        const parts = line.split('=');
        // Let's just output let directly. Standard simple declarations are fine.
      }

      // Translate scanf("%d", &n);
      // We look for scanf statements: scanf("%d", &n); or scanf("%d %d", &a, &b);
      if (line.includes('scanf')) {
        const scanfMatch = line.match(/scanf\s*\(\s*"([^"]+)"\s*,\s*(.+)\s*\)\s*;/);
        if (scanfMatch) {
          const format = scanfMatch[1];
          const vars = scanfMatch[2].split(',').map(v => v.trim().replace('&', ''));

          // Build async call
          if (vars.length === 1) {
            line = `${vars[0]} = Number(await scanf("값:"));`;
          } else {
            // Multiple vars: we can read one string, split by space, and assign
            const varAssignments = vars.map((v, idx) => `${v} = Number(inputs[${idx}]);`).join(' ');
            line = `
              const val_${i} = await scanf("값을 스পেস দিয়ে ইনপুট দিন:");
              const inputs = val_${i}.trim().split(/\\s+/);
              ${varAssignments}
            `;
          }
        }
      }

      // Translate printf to helper call:
      // printf("Sum = %d\n", sum); -> printf("Sum = %d\n", sum); (we bound printf to our printf_helper)
      // No replacement needed as our function is named printf!

      // Inject Loop counter protection inside loop bodies
      // If the line contains for or while, we want to inject __guardLoop() right after the opening curly brace
      if (/\b(for|while)\b/.test(line)) {
        if (line.includes('{')) {
          line = line.replace('{', '{ __guardLoop();');
        } else {
          // If no brace on same line, look at next lines or wrap them. 
          // For safety in student codes, we can expect they use { or we wrap it in transpilation.
        }
      }

      js += line + '\n';
    }

    return js;
  }
}
