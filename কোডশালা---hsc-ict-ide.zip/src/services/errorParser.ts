/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TranslatedError {
  title: string;
  explanation: string;
  suggestion: string;
}

export function parseCompilerError(rawError: string, language: 'c' | 'python' | 'sql'): TranslatedError {
  const errorLower = rawError.toLowerCase();

  if (language === 'c') {
    if (errorLower.includes("expected ';'") || errorLower.includes("expected ';' before")) {
      return {
        title: "সেমিকোলন (;) অনুপস্থিত",
        explanation: "আপনি সম্ভবত কোনো লাইনের শেষে সেমিকোলন (;) দিতে ভুলে গেছেন।",
        suggestion: "সি ল্যাঙ্গুয়েজে প্রতিটি সাধারণ স্টেটমেন্টের শেষে সেমিকোলন (;) দেওয়া বাধ্যতামূলক। পূর্ববর্তী লাইন বা উল্লেখিত লাইনের শেষে ';' দিন।"
      };
    }
    if (errorLower.includes("expected ')'")) {
      return {
        title: "বন্ধনী ')' শেষ করা হয়নি",
        explanation: "আপনি একটি ফার্স্ট ব্র্যাকেট শুরু করেছিলেন কিন্তু তা শেষ করতে ভুলে গেছেন।",
        suggestion: "নিশ্চিত করুন যে প্রতিটি '(' এর বিপরীতে একটি সমাপ্তি ')' রয়েছে।"
      };
    }
    if (errorLower.includes("expected '}'")) {
      return {
        title: "কোঁকড়া বন্ধনী '}' অনুপস্থিত",
        explanation: "আপনি কোনো ব্লক (যেমন main ফাংশন, if কন্ডিশন বা লুপ) শুরু করেছেন কিন্তু তা শেষ করতে সেকেন্ড ব্র্যাকেট '}' দিতে ভুলে গেছেন।",
        suggestion: "কোডের শেষভাগে বা ব্লকের সমাপ্তিতে একটি '}' যোগ করুন এবং কোডটি বিন্যস্ত রাখুন।"
      };
    }
    if (errorLower.includes("undeclared") || errorLower.includes("not declared")) {
      // Extract variable name if possible
      const match = rawError.match(/'([^']+)'/);
      const varName = match ? match[1] : "ভেরিয়েবল";
      return {
        title: `ভেরিয়েবল '${varName}' ডিক্লেয়ার করা হয়নি`,
        explanation: `আপনি '${varName}' নামক একটি ভেরিয়েবল বা মান ব্যবহার করার চেষ্টা করছেন যা সি কোডে আগে ডিক্লেয়ার (তৈরি) করা হয়নি।`,
        suggestion: `ভেরিয়েবলটি ব্যবহার করার আগে তার ডাটা টাইপ উল্লেখ করে তৈরি করুন। যেমন: int ${varName}; বা float ${varName};`
      };
    }
    if (errorLower.includes("conflicting types") || errorLower.includes("redeclaration")) {
      return {
        title: "ভেরিয়েবল পুনরায় তৈরি করা হয়েছে",
        explanation: "একই নামের ভেরিয়েবল একাধিকবার তৈরি (ডিক্লেয়ার) করা হয়েছে অথবা টাইপ পরিবর্তন করা হয়েছে।",
        suggestion: "একটি ব্লকের ভেতরে একই নামের ভেরিয়েবল কেবল একবারই ডিক্লেয়ার করুন।"
      };
    }
    if (errorLower.includes("implicit declaration of function")) {
      const match = rawError.match(/function '([^']+)'/);
      const funcName = match ? match[1] : "ফাংশন";
      return {
        title: `ফাংশন '${funcName}' খুঁজে পাওয়া যায়নি`,
        explanation: `আপনি '${funcName}' ফাংশনটি ব্যবহারের চেষ্টা করছেন কিন্তু এর জন্য প্রয়োজনীয় হেডার ফাইল যুক্ত করেননি অথবা ফাংশনটি তৈরি করেননি।`,
        suggestion: `আপনি যদি printf বা scanf ব্যবহার করতে চান, তবে কোডের একদম শুরুতে #include <stdio.h> লিখেছেন কি না তা নিশ্চিত করুন।`
      };
    }
  }

  if (language === 'python') {
    if (errorLower.includes("indentationerror")) {
      return {
        title: "ইনডেন্টেশন বা লাইন বিন্যাস ভুল (Indentation Error)",
        explanation: "পাইথনে কোডের ব্লক (যেমন if, for, while, def) বোঝানোর জন্য লাইনের শুরুতে সঠিক স্পেস বা ট্যাব ব্যবহার করতে হয়। এখানে সেই স্পেস ঠিক নেই।",
        suggestion: "if, for, বা while লাইনের ঠিক পরের লাইনটি ৪টি স্পেস (বা একটি ট্যাব) ডানে সরিয়ে শুরু করুন। ব্লকের সবগুলো লাইন সমান সমান্তরালে রাখুন।"
      };
    }
    if (errorLower.includes("nameerror")) {
      const match = rawError.match(/name '([^']+)'/);
      const varName = match ? match[1] : "ভেরিয়েবল";
      return {
        title: `নামের ভুল (Name Error) - '${varName}' তৈরি করা হয়নি`,
        explanation: `পাইথন '${varName}' নামক কোনো ভেরিয়েবল বা ফাংশন খুঁজে পাচ্ছে না।`,
        suggestion: `বানানটি ঠিক আছে কি না যাচাই করুন। মনে রাখবেন পাইথনে হাতের বড় অক্ষর ও ছোট অক্ষর আলাদা বিষয় (যেমন x এবং X এক নয়)। ব্যবহার করার আগে এই ভেরিয়েবলে কোনো মান অ্যাসাইন বা স্টোর করুন (যেমন: ${varName} = 10)।`
      };
    }
    if (errorLower.includes("syntaxerror")) {
      return {
        title: "গঠনগত ভুল (Syntax Error)",
        explanation: "আপনার পাইথন কোডের গঠনে কোনো ভুল আছে যা পাইথন রানার বুঝতে পারছে না।",
        suggestion: "কোলন (:) দিতে ভুলে গেছেন কি না দেখুন (যেমন class, def, if, for, while স্টেটমেন্টের শেষে)। এছাড়া ব্র্যাকেট বা কোটেশন চিহ্ন জোড়ায় জোড়ায় শেষ হয়েছে কি না চেক করুন।"
      };
    }
    if (errorLower.includes("zerodivisionerror")) {
      return {
        title: "শূন্য দ্বারা ভাগ ভুল (Zero Division Error)",
        explanation: "গণিতের নিয়ম অনুযায়ী কোনো কিছুকে শূন্য (0) দিয়ে ভাগ করা অবৈধ্য বা অসম্ভব। আপনার কোডে শূন্য দিয়ে ভাগের চেষ্টা করা হয়েছে।",
        suggestion: "ভাগের ক্ষেত্রে হর (divisor) যেন শূন্য না হয় তা নিশ্চিত করতে কন্ডিশন ব্যবহার করুন। যেমন: if divisor != 0:"
      };
    }
    if (errorLower.includes("typeerror")) {
      return {
        title: "ডাটা টাইপের অমিল (Type Error)",
        explanation: "আপনি ভিন্ন ক্যাটাগরির ডাটা টাইপ একসাথে যুক্ত বা ব্যবহার করার চেষ্টা করছেন (যেমন লেখার সাথে সংখ্যা সরাসরি যোগ করা)।",
        suggestion: "ইনপুট নেওয়ার পর সংখ্যায় রূপান্তর করতে int() বা float() ব্যবহার করুন। যেমন: number = int(input())। সংখ্যাকে লেখায় রূপান্তর করতে str() ব্যবহার করুন।"
      };
    }
    if (errorLower.includes("indexerror")) {
      return {
        title: "ইনডেক্স সীমার বাইরে (Index Error)",
        explanation: "আপনি লিস্টের এমন কোনো পজিশনের মান দেখতে চাচ্ছেন যা লিস্টের আকারের চেয়ে বড় বা সীমার বাইরে।",
        suggestion: "লিস্ট বা অ্যারের আকার চেক করুন। মনে রাখবেন ইনডেক্সিং শুরু হয় 0 থেকে, তাই Nটি উপাদানের জন্য সর্বোচ্চ ইনডেক্স হবে N-1।"
      };
    }
  }

  if (language === 'sql') {
    if (errorLower.includes("near") && errorLower.includes("syntax error")) {
      return {
        title: "এসকিউএল সিনট্যাক্স ভুল",
        explanation: "আপনার SQL কমান্ডটির লেখার গঠনে বা ব্যাকরণে কিছু ভুল রয়েছে।",
        suggestion: "SELECT, FROM, WHERE, INSERT INTO, CREATE TABLE কীওয়ার্ডগুলোর বানান চেক করুন এবং কমা (,) ও সেমিকোলন (;) সঠিক স্থানে বসেছে কি না দেখুন।"
      };
    }
    if (errorLower.includes("no such table")) {
      const match = rawError.match(/table: ([^ ]+)/) || rawError.match(/no such table: ([^ ]+)/);
      const tableName = match ? match[1] : "টেবিল";
      return {
        title: `টেবিল '${tableName}' পাওয়া যায়নি`,
        explanation: `আপনি '${tableName}' নামক টেবিলে কুয়েরি করার চেষ্টা করছেন কিন্তু এই টেবিলটি তৈরি করা হয়নি।`,
        suggestion: "টেবিলটির নাম ঠিকমতো লিখেছেন কি না যাচাই করুন। টেবিল তৈরি করার জন্য প্রথমে CREATE TABLE কমান্ডটি রান করতে হবে।"
      };
    }
    if (errorLower.includes("column") && errorLower.includes("not found")) {
      return {
        title: "কলামের নাম খুঁজে পাওয়া যায়নি",
        explanation: "আপনি টেবিলে এমন কোনো কলামের নাম ব্যবহার করেছেন যা ঐ টেবিলে উপস্থিত নেই।",
        suggestion: "টেবিল তৈরির সময় ডিফাইন করা কলামের নামের সাথে আপনার SELECT বা INSERT কুয়েরির কলামগুলোর বানান মিলিয়ে দেখুন।"
      };
    }
    if (errorLower.includes("unique constraint failed") || errorLower.includes("primary key")) {
      return {
        title: "প্রাইমারি কি বা ইউনিক কন্সট্রেইন্ট লঙ্ঘন",
        explanation: "আপনি এমন কোনো প্রাইমারি কি বা ইউনিক আইডেন্টিফায়ারের মান পুনরায় প্রবেশ করানোর চেষ্টা করছেন যা ইতিমধ্যে টেবিলে বিদ্যমান আছে।",
        suggestion: "প্রত্যেকটি রেকর্ডের জন্য আলাদা ও অনন্য প্রাইমারি কি (যেমন রোল বা আইডি) ব্যবহার নিশ্চিত করুন।"
      };
    }
  }

  // General catch-all fallback
  return {
    title: "কোড রান করতে সমস্যা হয়েছে",
    explanation: rawError,
    suggestion: "কোডের বানান, ব্র্যাকেট এবং কমা-সেমিকোলনগুলো লক্ষ্য করুন। প্রয়োজনে প্রদত্ত ডেমো বা টেমপ্লেট কোডটির সাথে মিলিয়ে দেখুন।"
  };
}
