/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CompilerResult, SQLQueryResult } from '../types';
import { parseCompilerError } from './errorParser';

interface Table {
  name: string;
  columns: string[];
  columnTypes: string[];
  rows: any[][];
}

export class SQLEngine {
  private tables: Record<string, Table> = {};

  /**
   * Resets the database to a blank state
   */
  clearDatabase() {
    this.tables = {};
  }

  /**
   * Run a series of SQL commands (supports multiple statements separated by semicolons)
   */
  execute(sqlCode: string): CompilerResult {
    const logs: CompilerResult['logs'] = [];
    let lastQueryResult: SQLQueryResult | undefined = undefined;
    let output = '';

    // Split statements by semicolon, ignoring those inside strings
    const statements = this.splitStatements(sqlCode);

    for (const rawStmt of statements) {
      const stmt = rawStmt.trim();
      if (stmt === '') continue;

      try {
        const lowerStmt = stmt.toLowerCase();

        // 1. CREATE TABLE
        if (lowerStmt.startsWith('create table')) {
          this.handleCreateTable(stmt);
          logs.push({ type: 'success', message: `টেবিল সফলভাবে তৈরি হয়েছে।` });
          output += `Query OK, table created.\n`;
        }
        // 2. INSERT INTO
        else if (lowerStmt.startsWith('insert into')) {
          const insertedCount = this.handleInsertInto(stmt);
          logs.push({ type: 'success', message: `${insertedCount}টি রেকর্ড সফলভাবে যুক্ত হয়েছে।` });
          output += `Query OK, ${insertedCount} row(s) affected.\n`;
        }
        // 3. SELECT
        else if (lowerStmt.startsWith('select')) {
          const queryResult = this.handleSelect(stmt);
          lastQueryResult = queryResult;
          const count = queryResult.rows.length;
          logs.push({ type: 'success', message: `কুয়েরি সফল হয়েছে (${count}টি রেকর্ড পাওয়া গেছে)।` });
          output += `Query OK, ${count} row(s) in set.\n`;
        }
        // Unknown or unsupported SQL
        else {
          throw new Error(`Unsupported statement near: "${stmt.substring(0, 15)}..."`);
        }
      } catch (err: any) {
        const errMsg = err.message || String(err);
        const translated = parseCompilerError(errMsg, 'sql');

        logs.push({ type: 'error', message: `এসকিউএল ত্রুটি: ${translated.title}` });
        logs.push({ type: 'error', message: `${translated.explanation}` });
        if (translated.suggestion) {
          logs.push({ type: 'info', message: `${translated.suggestion}` });
        }

        return {
          success: false,
          output: output + `Error: ${errMsg}\n`,
          logs,
          sqlResult: lastQueryResult
        };
      }
    }

    return {
      success: true,
      output: output + `\nExecution completed successfully.`,
      logs,
      sqlResult: lastQueryResult
    };
  }

  /**
   * Split statements safely considering semicolon in text strings
   */
  private splitStatements(sql: string): string[] {
    const statements: string[] = [];
    let current = '';
    let inString = false;
    let stringChar = '';

    for (let i = 0; i < sql.length; i++) {
      const char = sql[i];
      if ((char === "'" || char === '"') && sql[i - 1] !== '\\') {
        if (!inString) {
          inString = true;
          stringChar = char;
        } else if (stringChar === char) {
          inString = false;
        }
      }

      if (char === ';' && !inString) {
        statements.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    if (current.trim() !== '') {
      statements.push(current);
    }
    return statements;
  }

  /**
   * Handle: CREATE TABLE Students ( Roll INT, Name TEXT, GPA REAL );
   */
  private handleCreateTable(stmt: string) {
    const match = stmt.match(/create\s+table\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\((.+)\)/i);
    if (!match) {
      throw new Error("near \"CREATE TABLE\": syntax error");
    }

    const tableName = match[1];
    const columnsDef = match[2];

    // Split columns definition
    const colDefs = this.splitColumnDefinitions(columnsDef);
    const columns: string[] = [];
    const columnTypes: string[] = [];

    for (const colDef of colDefs) {
      const parts = colDef.trim().split(/\s+/);
      if (parts.length < 2) continue;
      
      const colName = parts[0];
      const colType = parts[1].toUpperCase();

      columns.push(colName);
      columnTypes.push(colType);
    }

    if (columns.length === 0) {
      throw new Error("Table must have at least one column definition.");
    }

    this.tables[tableName.toLowerCase()] = {
      name: tableName,
      columns,
      columnTypes,
      rows: []
    };
  }

  /**
   * Split column definitions taking constraints like PRIMARY KEY into account
   */
  private splitColumnDefinitions(def: string): string[] {
    const defs: string[] = [];
    let current = '';
    let parenCount = 0;

    for (let i = 0; i < def.length; i++) {
      const char = def[i];
      if (char === '(') parenCount++;
      if (char === ')') parenCount--;

      if (char === ',' && parenCount === 0) {
        defs.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    if (current.trim() !== '') {
      defs.push(current);
    }
    return defs;
  }

  /**
   * Handle: INSERT INTO Students VALUES (101, 'Rahman', 5.00);
   * or: INSERT INTO Students (Roll, Name) VALUES (101, 'Rahman');
   */
  private handleInsertInto(stmt: string): number {
    // 1. Check with column specifications
    const matchWithCols = stmt.match(/insert\s+into\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]+)\)\s*values\s*\((.+)\)/i);
    // 2. Check without column specifications
    const matchNoCols = stmt.match(/insert\s+into\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*values\s*\((.+)\)/i);

    if (!matchWithCols && !matchNoCols) {
      throw new Error("near \"INSERT INTO\": syntax error");
    }

    const tableName = (matchWithCols ? matchWithCols[1] : matchNoCols![1]).toLowerCase();
    const table = this.tables[tableName];

    if (!table) {
      throw new Error(`no such table: ${tableName}`);
    }

    let colNames: string[] = table.columns;
    let valuesStr = '';

    if (matchWithCols) {
      colNames = matchWithCols[2].split(',').map(s => s.trim());
      valuesStr = matchWithCols[3];
    } else {
      valuesStr = matchNoCols![2];
    }

    // Parse values list
    const values = this.parseValuesList(valuesStr);

    if (values.length !== colNames.length && !matchWithCols) {
      throw new Error(`Column count mismatch. Table has ${table.columns.length} columns, but ${values.length} values were provided.`);
    }

    // Create new row with default values
    const newRow = new Array(table.columns.length).fill(null);

    for (let i = 0; i < colNames.length; i++) {
      const targetCol = colNames[i];
      const colIdx = table.columns.findIndex(c => c.toLowerCase() === targetCol.toLowerCase());
      if (colIdx === -1) {
        throw new Error(`column "${targetCol}" not found in table "${table.name}"`);
      }

      const val = matchWithCols ? values[i] : values[colIdx];
      newRow[colIdx] = val;
    }

    table.rows.push(newRow);
    return 1;
  }

  /**
   * Parses values in VALUES list, handles strings, numbers, etc.
   */
  private parseValuesList(valStr: string): any[] {
    const values: any[] = [];
    let current = '';
    let inString = false;
    let stringChar = '';

    for (let i = 0; i < valStr.length; i++) {
      const char = valStr[i];
      if (char === "'" || char === '"') {
        if (!inString) {
          inString = true;
          stringChar = char;
        } else if (stringChar === char) {
          inString = false;
        }
      } else if (char === ',' && !inString) {
        values.push(this.castValue(current.trim()));
        current = '';
      } else {
        current += char;
      }
    }
    if (current.trim() !== '') {
      values.push(this.castValue(current.trim()));
    }

    return values;
  }

  private castValue(val: string): any {
    if (val === 'NULL' || val === 'null' || val === '') {
      return null;
    }
    if ((val.startsWith("'") && val.endsWith("'")) || (val.startsWith('"') && val.endsWith('"'))) {
      return val.substring(1, val.length - 1);
    }
    const num = Number(val);
    return isNaN(num) ? val : num;
  }

  /**
   * Handle: SELECT Roll, Name, GPA FROM Students WHERE GPA >= 4.5 ORDER BY Roll DESC;
   */
  private handleSelect(stmt: string): SQLQueryResult {
    const selectRegex = /select\s+(.+)\s+from\s+([a-zA-Z_][a-zA-Z0-9_]*)(?:\s+where\s+(.+?))?(?:\s+order\s+by\s+(.+?))?$/i;
    
    // Normalize spaces but preserve string constants
    const normalizedStmt = stmt.replace(/\s+/g, ' ').trim();
    const match = normalizedStmt.match(selectRegex);

    if (!match) {
      throw new Error("near \"SELECT\": syntax error");
    }

    const colSelectionStr = match[1];
    const tableName = match[2].toLowerCase();
    const whereClause = match[3];
    const orderByClause = match[4];

    const table = this.tables[tableName];
    if (!table) {
      throw new Error(`no such table: ${tableName}`);
    }

    // Determine projected columns
    let projectedColumns: string[] = [];
    let projectedIndices: number[] = [];

    if (colSelectionStr.trim() === '*') {
      projectedColumns = [...table.columns];
      projectedIndices = table.columns.map((_, idx) => idx);
    } else {
      const colNames = colSelectionStr.split(',').map(s => s.trim());
      for (const colName of colNames) {
        const idx = table.columns.findIndex(c => c.toLowerCase() === colName.toLowerCase());
        if (idx === -1) {
          throw new Error(`column "${colName}" not found in table "${table.name}"`);
        }
        projectedColumns.push(table.columns[idx]);
        projectedIndices.push(idx);
      }
    }

    // Filter rows via WHERE clause
    let filteredRows = [...table.rows];
    if (whereClause) {
      filteredRows = filteredRows.filter(row => this.evaluateWhere(row, table.columns, whereClause));
    }

    // Sort rows via ORDER BY clause
    if (orderByClause) {
      const orderParts = orderByClause.trim().split(/\s+/);
      const orderColName = orderParts[0];
      const direction = orderParts[1] ? orderParts[1].toUpperCase() : 'ASC';

      const sortColIdx = table.columns.findIndex(c => c.toLowerCase() === orderColName.toLowerCase());
      if (sortColIdx === -1) {
        throw new Error(`column "${orderColName}" not found in table "${table.name}" for sorting`);
      }

      filteredRows.sort((rowA, rowB) => {
        const valA = rowA[sortColIdx];
        const valB = rowB[sortColIdx];

        if (valA === null) return 1;
        if (valB === null) return -1;

        if (typeof valA === 'number' && typeof valB === 'number') {
          return direction === 'DESC' ? valB - valA : valA - valB;
        }

        const strA = String(valA);
        const strB = String(valB);
        return direction === 'DESC' ? strB.localeCompare(strA) : strA.localeCompare(strB);
      });
    }

    // Construct final projection rows
    const finalRows = filteredRows.map(row => {
      return projectedIndices.map(idx => row[idx]);
    });

    return {
      columns: projectedColumns,
      rows: finalRows
    };
  }

  /**
   * Simple WHERE expression evaluation supporting =, >, <, >=, <=, !=
   */
  private evaluateWhere(row: any[], columns: string[], clause: string): boolean {
    const operators = ['>=', '<=', '!=', '=', '>', '<'];
    let selectedOp = '';
    let colName = '';
    let testValStr = '';

    for (const op of operators) {
      if (clause.includes(op)) {
        selectedOp = op;
        const parts = clause.split(op);
        colName = parts[0].trim();
        testValStr = parts[1].trim();
        break;
      }
    }

    if (!selectedOp) {
      // If no explicit comparison, check if column name exists and has value
      const idx = columns.findIndex(c => c.toLowerCase() === clause.trim().toLowerCase());
      if (idx !== -1) return !!row[idx];
      return true;
    }

    const colIdx = columns.findIndex(c => c.toLowerCase() === colName.toLowerCase());
    if (colIdx === -1) {
      throw new Error(`column "${colName}" not found in WHERE filter`);
    }

    const actualVal = row[colIdx];
    const testVal = this.castValue(testValStr);

    if (actualVal === null) return false;

    switch (selectedOp) {
      case '=':
        return String(actualVal) === String(testVal);
      case '!=':
        return String(actualVal) !== String(testVal);
      case '>':
        return actualVal > testVal;
      case '<':
        return actualVal < testVal;
      case '>=':
        return actualVal >= testVal;
      case '<=':
        return actualVal <= testVal;
      default:
        return true;
    }
  }
}
