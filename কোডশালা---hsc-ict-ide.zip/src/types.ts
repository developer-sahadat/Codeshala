/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'c' | 'python' | 'sql' | 'html';

export type AppTheme = 'light' | 'dark' | 'system';

export type EditorTheme = 'one-dark' | 'github-light';

export interface Project {
  id: string;
  name: string;
  language: Language;
  code: string;
  createdAt: string;
  updatedAt: string;
  isArchived: boolean;
  dbState?: string; // Optional saved state for SQL databases (JSON string representing simulated tables)
}

export interface Settings {
  theme: AppTheme;
  editorTheme: EditorTheme;
  fontSize: number; // in pixels (e.g., 14, 16, 18)
  autoSave: boolean;
  language: 'bn' | 'en'; // Bengali is default, English is fallback
}

export interface CompilerResult {
  success: boolean;
  output: string;
  logs: Array<{
    type: 'success' | 'warning' | 'error' | 'info';
    message: string;
    line?: number;
  }>;
  sqlResult?: SQLQueryResult;
  htmlCode?: string;
}

export interface SQLQueryResult {
  columns: string[];
  rows: any[][];
}

export interface DeveloperInfo {
  name: string;
  role: string;
  affiliation: string;
  bio: string;
  avatarUrl: string;
  socials: {
    facebook: string;
    telegram: string;
    email: string;
  };
}
