/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Terminal, Copy, Trash2, ChevronDown, ChevronUp, Check, Database, AlertCircle, Info, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CompilerResult } from '../types';

interface OutputBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  result: CompilerResult | null;
  onClearOutput: () => void;
}

export default function OutputBottomSheet({ isOpen, onClose, result, onClearOutput }: OutputBottomSheetProps) {
  const [heightMode, setHeightMode] = useState<'30' | '60' | '100'>('60');
  const [logCopied, setLogCopied] = useState(false);
  const [cellCopiedVal, setCellCopiedVal] = useState<string | null>(null);

  if (!isOpen) return null;

  const getHeightClass = () => {
    switch (heightMode) {
      case '30': return 'h-[30vh]';
      case '100': return 'h-[95vh] rounded-t-[28px]';
      case '60':
      default: return 'h-[60vh]';
    }
  };

  const handleCopyLogs = () => {
    if (!result) return;
    const textToCopy = `=== কোডশালা আউটপুট ===\n${result.output}\n\n=== লগসমূহ ===\n${result.logs.map(l => l.message).join('\n')}`;
    navigator.clipboard.writeText(textToCopy);
    setLogCopied(true);
    setTimeout(() => setLogCopied(false), 2000);
  };

  const handleCopyCell = (val: any) => {
    const str = String(val);
    navigator.clipboard.writeText(str);
    setCellCopiedVal(str);
    setTimeout(() => setCellCopiedVal(null), 1500);
  };

  const handleCopySQLTable = () => {
    if (!result?.sqlResult) return;
    const { columns, rows } = result.sqlResult;
    const header = columns.join('\t');
    const body = rows.map(r => r.join('\t')).join('\n');
    navigator.clipboard.writeText(`${header}\n${body}`);
    setLogCopied(true);
    setTimeout(() => setLogCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center pointer-events-none">
      {/* Dim backdrop only for full screen mode */}
      {heightMode === '100' && (
        <div 
          className="fixed inset-0 bg-[#090909]/40 z-30 pointer-events-auto"
          onClick={() => setHeightMode('60')}
          id="output-sheet-backdrop"
        />
      )}

      {/* Sheet Container */}
      <div
        className={`w-full max-w-4xl bg-white dark:bg-[#151515] border-t border-gray-100 dark:border-gray-800 shadow-2xl pointer-events-auto transition-all duration-300 flex flex-col z-40 rounded-t-[22px] ${getHeightClass()}`}
        id="output-sheet-container"
      >
        {/* Handle / Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-gray-50/70 dark:bg-[#1E1E1E]/80 border-b border-gray-100 dark:border-gray-800 rounded-t-[22px]">
          <div className="flex items-center gap-2">
            <Terminal className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            <span className="font-bold text-gray-800 dark:text-white font-sans text-sm">আউটপুট প্যানেল</span>
            {result && (
              <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${result.success ? 'bg-green-50 text-green-700 dark:bg-green-900/10 dark:text-green-400' : 'bg-red-50 text-red-700 dark:bg-red-900/10 dark:text-red-400'}`}>
                {result.success ? 'সফল' : 'ত্রুটি'}
              </span>
            )}
          </div>

          {/* Size Selectors & Controls */}
          <div className="flex items-center gap-2 font-sans">
            <div className="flex bg-gray-200/60 dark:bg-gray-800 rounded-lg p-0.5 text-xs font-medium">
              {(['30', '60', '100'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => setHeightMode(mode)}
                  className={`px-2.5 py-1 rounded-md transition-all ${heightMode === mode ? 'bg-white dark:bg-[#151515] text-[#4F7DF7] dark:text-[#6EA8FE] shadow-[0_1px_2px_rgba(0,0,0,0.08)]' : 'text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white'}`}
                  id={`height-btn-${mode}`}
                >
                  {mode === '30' ? '৩০%' : mode === '60' ? '৬০%' : '১০০%'}
                </button>
              ))}
            </div>

            <div className="h-4 w-px bg-gray-200 dark:bg-gray-700 mx-1" />

            {/* Quick Actions */}
            <button
              onClick={handleCopyLogs}
              disabled={!result}
              className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-200/50 dark:text-gray-400 dark:hover:bg-gray-800 disabled:opacity-30 transition-colors"
              title="আউটপুট কপি করুন"
              id="copy-logs-btn"
            >
              {logCopied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
            </button>
            <button
              onClick={onClearOutput}
              disabled={!result}
              className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-200/50 hover:text-red-500 dark:text-gray-400 dark:hover:bg-gray-800 disabled:opacity-30 transition-colors"
              title="আউটপুট মুছুন"
              id="clear-logs-btn"
            >
              <Trash2 className="h-4 w-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-200/50 dark:text-gray-400 dark:hover:bg-gray-800 transition-colors"
              id="close-logs-btn"
            >
              <ChevronDown className="h-4.5 w-4.5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 bg-gray-50 dark:bg-[#090909]" id="output-content-area">
          <AnimatePresence mode="wait">
            {!result ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex flex-col items-center justify-center text-center p-6"
                id="no-output-placeholder"
              >
                <Terminal className="h-10 w-10 text-gray-300 dark:text-gray-700 mb-2 stroke-[1.5]" />
                <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 font-sans">কোনো রান রেকর্ড নেই</p>
                <p className="text-xs text-gray-400 dark:text-gray-600 font-sans mt-0.5">কোড রান করতে উপরের 'রান করুন' বোতামে চাপ দিন</p>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
                id="output-result-container"
              >
                {/* 0. Live Web View Preview */}
                {result.htmlCode !== undefined && (
                  <div className="bg-white dark:bg-[#151515] rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.02)] border border-gray-100 dark:border-gray-800 flex flex-col">
                    <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase font-sans tracking-wider mb-2">লাইভ ওয়েব প্রিভিউ (Live Web View)</span>
                    <div className="w-full h-[320px] rounded-lg border border-gray-200 dark:border-gray-700 bg-white overflow-hidden relative">
                      <iframe
                        srcDoc={result.htmlCode}
                        title="HTML Output Preview"
                        className="w-full h-full border-none bg-white"
                        sandbox="allow-scripts"
                      />
                    </div>
                  </div>
                )}

                {/* 1. Terminal Text Output Console */}
                <div className="bg-white dark:bg-[#151515] rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.02)] border border-gray-100 dark:border-gray-800 flex flex-col">
                  <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase font-mono tracking-wider mb-2">স্ট্যান্ডার্ড আউটপুট (Console)</span>
                  <pre className="font-mono text-sm leading-relaxed whitespace-pre-wrap select-text text-gray-800 dark:text-gray-200 bg-gray-50 dark:bg-[#090909] p-3 rounded-lg overflow-x-auto max-h-[250px] border border-gray-100 dark:border-gray-800">
                    {result.output || <span className="italic text-gray-400 dark:text-gray-600">কোনো টেক্সট আউটপুট নেই।</span>}
                  </pre>
                </div>

                {/* 2. SQL DataTable output if present */}
                {result.sqlResult && (
                  <div className="bg-white dark:bg-[#151515] rounded-xl p-4 shadow-[0_1px_3px_rgba(0,0,0,0.02)] border border-gray-100 dark:border-gray-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1.5">
                        <Database className="h-4.5 w-4.5 text-[#4F7DF7] dark:text-[#6EA8FE]" />
                        <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase font-sans tracking-wider">ডাটাবেজ টেবিল ভিউ (SQL Table)</span>
                      </div>
                      <button
                        onClick={handleCopySQLTable}
                        className="flex items-center gap-1 text-xs text-[#4F7DF7] hover:underline font-semibold dark:text-[#6EA8FE]"
                        id="copy-sql-table-btn"
                      >
                        <Copy className="h-3.5 w-3.5" />
                        <span>পুরো টেবিল কপি করুন</span>
                      </button>
                    </div>

                    {result.sqlResult.rows.length === 0 ? (
                      <div className="p-4 bg-gray-50 dark:bg-[#090909] rounded-lg text-center border border-gray-100 dark:border-gray-800">
                        <span className="text-xs text-gray-500 dark:text-gray-400 font-sans">টেবিলটিতে কোনো রেকর্ড বা সারি নেই।</span>
                      </div>
                    ) : (
                      <div className="overflow-x-auto rounded-lg border border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-[#090909] relative">
                        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-800">
                          {/* Sticky Header */}
                          <thead className="bg-gray-100 dark:bg-[#1E1E1E] sticky top-0 z-10">
                            <tr>
                              {result.sqlResult.columns.map((col, idx) => (
                                <th
                                  key={idx}
                                  scope="col"
                                  className="px-4 py-3 text-left text-xs font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider font-mono select-none"
                                >
                                  {col}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          {/* Alternating Row Colors */}
                          <tbody className="bg-white dark:bg-[#151515] divide-y divide-gray-200 dark:divide-gray-800">
                            {result.sqlResult.rows.map((row, rowIdx) => (
                              <tr
                                key={rowIdx}
                                className={rowIdx % 2 === 0 ? 'bg-white dark:bg-[#151515]' : 'bg-gray-50/50 dark:bg-[#1E1E1E]/40'}
                              >
                                {row.map((cell, cellIdx) => (
                                  <td
                                    key={cellIdx}
                                    onClick={() => handleCopyCell(cell)}
                                    className="px-4 py-2.5 text-sm font-mono text-gray-800 dark:text-gray-200 cursor-pointer hover:bg-blue-50/40 dark:hover:bg-blue-900/10 active:bg-blue-100/50 transition-all select-all relative"
                                    title="কপি করতে ক্লিক করুন"
                                  >
                                    {cell === null ? (
                                      <span className="italic text-gray-400 font-sans">NULL</span>
                                    ) : (
                                      String(cell)
                                    )}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}

                {/* 3. Compilation Logs */}
                <div className="space-y-1.5">
                  <span className="text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase font-mono tracking-wider">রানার লগ রিপোর্ট</span>
                  <div className="space-y-1">
                    {result.logs.map((log, index) => {
                      let logColor = 'text-gray-600 dark:text-gray-400 bg-gray-100/40 dark:bg-gray-800/10';
                      let icon = <Info className="h-4 w-4 shrink-0 text-gray-400" />;

                      if (log.type === 'success') {
                        logColor = 'text-green-800 dark:text-green-400 bg-green-50/50 dark:bg-green-950/10 border-green-100 dark:border-green-900/20';
                        icon = <CheckCircle className="h-4 w-4 shrink-0 text-green-500 dark:text-green-400" />;
                      } else if (log.type === 'error') {
                        logColor = 'text-red-800 dark:text-red-400 bg-red-50/50 dark:bg-red-950/10 border-red-100 dark:border-red-900/20';
                        icon = <AlertCircle className="h-4 w-4 shrink-0 text-red-500 dark:text-red-400" />;
                      } else if (log.type === 'warning') {
                        logColor = 'text-amber-800 dark:text-amber-400 bg-amber-50/50 dark:bg-amber-950/10 border-amber-100 dark:border-amber-900/20';
                        icon = <AlertCircle className="h-4 w-4 shrink-0 text-amber-500 dark:text-amber-400" />;
                      }

                      return (
                        <div
                          key={index}
                          className={`flex items-start gap-2.5 p-2.5 text-xs font-sans rounded-lg border ${logColor}`}
                        >
                          {icon}
                          <span className="leading-normal select-text">{log.message}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Embedded toast for cells */}
      <AnimatePresence>
        {cellCopiedVal !== null && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 z-50 px-4 py-2 bg-gray-900 text-white dark:bg-white dark:text-[#090909] text-xs font-semibold rounded-full shadow-lg font-sans flex items-center gap-1.5 pointer-events-auto"
            id="cell-copied-toast"
          >
            <Check className="h-3.5 w-3.5 text-green-500" />
            <span>"{cellCopiedVal.substring(0, 15)}{cellCopiedVal.length > 15 ? '...' : ''}" কপি হয়েছে</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
