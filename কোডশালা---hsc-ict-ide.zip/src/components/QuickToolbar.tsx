/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Language } from '../types';

interface QuickToolbarProps {
  language: Language;
  onInsertSymbol: (symbol: string) => void;
}

export default function QuickToolbar({ language, onInsertSymbol }: QuickToolbarProps) {
  // Get language-specific snippet suggestions
  const getSymbols = (): Array<{ display: string; value: string }> => {
    switch (language) {
      case 'html':
        return [
          { display: '<html>', value: '<html>\n\n</html>' },
          { display: '<head>', value: '<head>\n    <title></title>\n</head>' },
          { display: '<body>', value: '<body>\n    \n</body>' },
          { display: '<table>', value: '<table border="1">\n    <tr>\n        <td></td>\n    </tr>\n</table>' },
          { display: '<tr>', value: '<tr>\n    \n</tr>' },
          { display: '<td>', value: '<td></td>' },
          { display: '<th>', value: '<th></th>' },
          { display: '<h1>', value: '<h1></h1>' },
          { display: '<p>', value: '<p></p>' },
          { display: '<img>', value: '<img src="" alt="">' },
          { display: '<a>', value: '<a href=""></a>' },
          { display: '<style>', value: '<style>\n    \n</style>' },
          { display: '<script>', value: '<script>\n    \n</script>' },
          { display: '=', value: '=' },
          { display: '"', value: '"' }
        ];
      case 'sql':
        return [
          { display: 'SELECT', value: 'SELECT * FROM ' },
          { display: 'WHERE', value: 'WHERE ' },
          { display: 'INSERT', value: 'INSERT INTO ' },
          { display: 'CREATE', value: 'CREATE TABLE ' },
          { display: 'VALUES', value: 'VALUES ()' },
          { display: 'PRIMARY KEY', value: 'PRIMARY KEY' },
          { display: '*', value: '*' },
          { display: ';', value: ';' },
          { display: '=', value: '=' },
          { display: ',', value: ', ' },
          { display: '\'', value: '\'' }
        ];
      case 'python':
        return [
          { display: ':', value: ':' },
          { display: '()', value: '()' },
          { display: '[]', value: '[]' },
          { display: 'print', value: 'print("")' },
          { display: 'input', value: 'input("")' },
          { display: 'if', value: 'if :' },
          { display: 'for', value: 'for i in range():' },
          { display: 'def', value: 'def ():' },
          { display: '=', value: '=' },
          { display: '+', value: '+' },
          { display: '-', value: '-' },
          { display: '*', value: '*' },
          { display: '/', value: '/' }
        ];
      case 'c':
      default:
        return [
          { display: '{}', value: '{}' },
          { display: '()', value: '()' },
          { display: ';', value: ';' },
          { display: '"', value: '"' },
          { display: '#include', value: '#include <stdio.h>\n' },
          { display: 'printf', value: 'printf("");' },
          { display: 'scanf', value: 'scanf("");' },
          { display: 'if', value: 'if ()' },
          { display: 'for', value: 'for (int i = 0; i < n; i++) {\n    \n}' },
          { display: '=', value: '=' },
          { display: '+', value: '+' },
          { display: '-', value: '-' },
          { display: '*', value: '*' },
          { display: '/', value: '/' },
          { display: '&', value: '&' }
        ];
    }
  };

  const symbols = getSymbols();

  return (
    <div
      className="flex w-full items-center border-y border-gray-100 bg-gray-50/85 px-2 py-1.5 backdrop-blur-md dark:border-gray-800 dark:bg-[#151515]/90 overflow-x-auto scrollbar-none"
      id="quick-toolbar-container"
      style={{ scrollbarWidth: 'none' }} // hide standard scrollbars
    >
      <div className="flex gap-1.5 px-1">
        {symbols.map((sym, index) => (
          <motion.button
            key={`${sym.value}-${index}`}
            whileTap={{ scale: 0.9 }}
            onClick={() => onInsertSymbol(sym.value)}
            className="flex h-10 min-w-10 items-center justify-center rounded-lg bg-white px-3 font-mono text-xs font-semibold text-gray-700 shadow-[0_1px_2px_rgba(0,0,0,0.05)] hover:bg-gray-100 dark:bg-[#1E1E1E] dark:text-gray-200 dark:hover:bg-gray-800 transition-colors shrink-0"
            id={`sym-btn-${index}`}
          >
            {sym.display}
          </motion.button>
        ))}
      </div>
    </div>
  );
}
