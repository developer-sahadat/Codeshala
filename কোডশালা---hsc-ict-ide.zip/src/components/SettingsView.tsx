/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Sun, 
  Moon, 
  Laptop, 
  Sparkles, 
  BookOpen, 
  ShieldCheck, 
  FileText, 
  User, 
  Info, 
  ChevronRight, 
  Check, 
  Sliders, 
  Compass, 
  ArrowLeft 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings, AppTheme, EditorTheme } from '../types';
import AboutDeveloperDialog from './AboutDeveloperDialog';

interface SettingsViewProps {
  settings: Settings;
  onUpdateSettings: (s: Settings) => void;
}

export default function SettingsView({ settings, onUpdateSettings }: SettingsViewProps) {
  const [subView, setSubView] = useState<'none' | 'about_codeshala' | 'privacy' | 'terms'>('none');
  const [isDevDialogOpen, setIsDevDialogOpen] = useState(false);

  // Quick theme setter
  const setTheme = (theme: AppTheme) => {
    onUpdateSettings({ ...settings, theme });
  };

  const setEditorTheme = (editorTheme: EditorTheme) => {
    onUpdateSettings({ ...settings, editorTheme });
  };

  const setFontSize = (fontSize: number) => {
    onUpdateSettings({ ...settings, fontSize });
  };

  const toggleAutoSave = () => {
    onUpdateSettings({ ...settings, autoSave: !settings.autoSave });
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto pb-12 font-sans text-gray-800 dark:text-gray-100" id="settings-view-main">
      <AnimatePresence mode="wait">
        {subView === 'none' ? (
          <motion.div
            key="settings-list"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-6"
          >
            {/* 1. Theme Configuration & Sizing */}
            <div className="bg-white dark:bg-[#151515] rounded-3xl p-6 shadow-[0_4px_20px_rgba(0,0,0,0.02)] border border-gray-100 dark:border-gray-800 space-y-5">
              <div className="flex items-center gap-2 pb-2 border-b border-gray-100 dark:border-gray-800">
                <Sliders className="h-5 w-5 text-[#4F7DF7] dark:text-[#6EA8FE]" />
                <h3 className="font-bold text-base">সিস্টেম কনফিগারেশন (Preferences)</h3>
              </div>

              {/* Theme selection */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-500 dark:text-gray-400">অ্যাপ কালার থিম</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['light', 'dark', 'system'] as const).map(themeOpt => {
                    const isActive = settings.theme === themeOpt;
                    const labels = { light: 'লাইট থিম', dark: 'ডার্ক থিম', system: 'সিস্টেম' };
                    const icons = {
                      light: <Sun className="h-4.5 w-4.5" />,
                      dark: <Moon className="h-4.5 w-4.5" />,
                      system: <Laptop className="h-4.5 w-4.5" />
                    };

                    return (
                      <button
                        key={themeOpt}
                        onClick={() => setTheme(themeOpt)}
                        className={`flex flex-col items-center justify-center gap-1.5 py-3.5 px-3 rounded-2xl border text-xs font-semibold transition-all cursor-pointer ${isActive ? 'bg-[#4F7DF7]/5 text-[#4F7DF7] border-[#4F7DF7] dark:bg-[#6EA8FE]/10 dark:text-[#6EA8FE] dark:border-[#6EA8FE] shadow-sm' : 'bg-transparent text-gray-500 border-gray-200 hover:border-gray-300 dark:border-gray-800 dark:text-gray-400 dark:hover:border-gray-700'}`}
                        id={`theme-select-${themeOpt}`}
                      >
                        {icons[themeOpt]}
                        <span>{labels[themeOpt]}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Editor Theme selection */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-500 dark:text-gray-400">কোড এডিটর থিম (Skins)</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'one-dark', label: 'One Dark Pro', desc: 'চোখের জন্য আরামদায়ক ডার্ক থিম' },
                    { key: 'github-light', label: 'GitHub Light', desc: 'উজ্জ্বল লাইট এডিটর থিম' }
                  ].map(edTheme => {
                    const isActive = settings.editorTheme === edTheme.key;
                    return (
                      <button
                        key={edTheme.key}
                        onClick={() => setEditorTheme(edTheme.key as EditorTheme)}
                        className={`flex flex-col items-start p-4 rounded-2xl border text-left cursor-pointer transition-all ${isActive ? 'bg-[#4F7DF7]/5 text-[#4F7DF7] border-[#4F7DF7] dark:bg-[#6EA8FE]/10 dark:text-[#6EA8FE] dark:border-[#6EA8FE] shadow-sm' : 'bg-transparent text-gray-600 border-gray-200 hover:border-gray-300 dark:border-gray-800 dark:text-gray-300 dark:hover:border-gray-700'}`}
                        id={`ed-theme-select-${edTheme.key}`}
                      >
                        <span className="text-sm font-bold">{edTheme.label}</span>
                        <span className="text-[10px] text-gray-400 mt-0.5 leading-none">{edTheme.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Font Sizing */}
              <div className="flex items-center justify-between py-2">
                <div className="flex flex-col">
                  <span className="text-sm font-bold">এডিটরের ফন্ট সাইজ (Font Size)</span>
                  <span className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">কোড পড়ার সুবিধাজনক আকার নির্ধারণ করুন</span>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setFontSize(Math.max(12, settings.fontSize - 1))}
                    className="flex h-9 w-9 items-center justify-center rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 font-bold transition-all text-sm"
                    id="font-size-dec"
                  >
                    -
                  </button>
                  <span className="font-mono text-sm font-bold w-12 text-center" id="font-size-val">
                    {settings.fontSize}px
                  </span>
                  <button
                    onClick={() => setFontSize(Math.min(24, settings.fontSize + 1))}
                    className="flex h-9 w-9 items-center justify-center rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 font-bold transition-all text-sm"
                    id="font-size-inc"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Auto Save Toggle */}
              <div className="flex items-center justify-between py-2 border-t border-gray-100 dark:border-gray-800 pt-4">
                <div className="flex flex-col">
                  <span className="text-sm font-bold">অটো সেভ (Auto Save)</span>
                  <span className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">টাইপ শেষ করার সাথে সাথে কোড স্বয়ংক্রিয়ভাবে সেভ হবে</span>
                </div>
                <button
                  onClick={toggleAutoSave}
                  className={`relative inline-flex h-6.5 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${settings.autoSave ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-700'}`}
                  id="auto-save-toggle"
                >
                  <span
                    className={`pointer-events-none inline-block h-5.5 w-5.5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${settings.autoSave ? 'translate-x-5.5' : 'translate-x-0'}`}
                  />
                </button>
              </div>
            </div>

            {/* 2. Educational & Legal Links */}
            <div className="bg-white dark:bg-[#151515] rounded-3xl p-4 shadow-[0_4px_20px_rgba(0,0,0,0.02)] border border-gray-100 dark:border-gray-800 divide-y divide-gray-100 dark:divide-gray-800">
              <button
                onClick={() => setSubView('about_codeshala')}
                className="flex w-full items-center justify-between p-4 hover:bg-gray-50/50 dark:hover:bg-[#1E1E1E]/50 rounded-2xl transition-colors cursor-pointer group"
                id="link-about-codeshala"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-950/20 text-[#4F7DF7] dark:text-[#6EA8FE]">
                    <BookOpen className="h-5 w-5" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-sm font-bold">কোডশালা সম্পর্কে (About Codeshala)</span>
                    <span className="text-xs text-gray-400 mt-0.5">উদ্দেশ্য, ফিচার এবং প্রযুক্তিগত বিবরণ</span>
                  </div>
                </div>
                <ChevronRight className="h-4.5 w-4.5 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => setIsDevDialogOpen(true)}
                className="flex w-full items-center justify-between p-4 hover:bg-gray-50/50 dark:hover:bg-[#1E1E1E]/50 rounded-2xl transition-colors cursor-pointer group"
                id="link-about-developer"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-orange-50 dark:bg-orange-950/20 text-orange-500">
                    <User className="h-5 w-5" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-sm font-bold">ডেভেলপার পরিচিতি (About Developer)</span>
                    <span className="text-xs text-gray-400 mt-0.5">মোঃ শাহাদাত হোসাইন (প্রতিষ্ঠাতা, কোডশালা)</span>
                  </div>
                </div>
                <ChevronRight className="h-4.5 w-4.5 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => setSubView('privacy')}
                className="flex w-full items-center justify-between p-4 hover:bg-gray-50/50 dark:hover:bg-[#1E1E1E]/50 rounded-2xl transition-colors cursor-pointer group"
                id="link-privacy"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-50 dark:bg-green-950/20 text-green-500">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-sm font-bold">প্রাইভেসি পলিসি (Privacy Policy)</span>
                    <span className="text-xs text-gray-400 mt-0.5">ডাটা সংগ্রহ, লোকাল স্টোরেজ ও নিরাপত্তা</span>
                  </div>
                </div>
                <ChevronRight className="h-4.5 w-4.5 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={() => setSubView('terms')}
                className="flex w-full items-center justify-between p-4 hover:bg-gray-50/50 dark:hover:bg-[#1E1E1E]/50 rounded-2xl transition-colors cursor-pointer group"
                id="link-terms"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-50 dark:bg-cyan-950/20 text-cyan-500">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-sm font-bold">শর্তাবলী ও নিয়মাবলি (Terms & Conditions)</span>
                    <span className="text-xs text-gray-400 mt-0.5">ব্যবহারবিধি, মেধাস্বত্ব এবং আইনি নিয়মসমূহ</span>
                  </div>
                </div>
                <ChevronRight className="h-4.5 w-4.5 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

            {/* Footer Credit & Static Version Display */}
            <div className="text-center space-y-1.5 pt-4">
              <span className="inline-flex items-center gap-1.5 text-xs text-gray-400 dark:text-gray-500 font-medium">
                <Sparkles className="h-3 w-3" />
                <span>কোডশালা - শিক্ষা ও উদ্ভাবনের মেলবন্ধন</span>
              </span>
              <p className="text-[10px] text-gray-400 dark:text-gray-600 font-mono">
                App Version: 2.1.0 • Build Number: 2026.06.27 • Copyright © 2026 Codeshala. All rights reserved.
              </p>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="sub-view-panel"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -15 }}
            className="bg-white dark:bg-[#151515] rounded-3xl p-6 shadow-[0_4px_20px_rgba(0,0,0,0.02)] border border-gray-100 dark:border-gray-800 relative"
          >
            {/* Nav Back Header */}
            <div className="sticky top-0 bg-white/95 dark:bg-[#151515]/95 backdrop-blur-md py-3.5 mb-4 -mx-6 px-6 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between z-20 rounded-t-3xl">
              <button
                onClick={() => setSubView('none')}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#4F7DF7] hover:underline dark:text-[#6EA8FE] cursor-pointer"
                id="settings-back-btn"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>ফিরে যান</span>
              </button>
            </div>

            {/* --- Render "About Codeshala" --- */}
            {subView === 'about_codeshala' && (
              <div className="space-y-5" id="about-codeshala-page">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-100 dark:border-gray-800">
                  <BookOpen className="h-5.5 w-5.5 text-[#4F7DF7] dark:text-[#6EA8FE]" />
                  <h2 className="text-lg font-bold">কোডশালা সম্পর্কে (About Codeshala)</h2>
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed space-y-4">
                  <p>
                    <strong>কোডশালা (Codeshala)</strong> বাংলাদেশের অন্যতম সেরা অফলাইন-ফার্স্ট আইসিটি লার্নিং প্ল্যাটফর্ম, যা বিশেষভাবে এইচএসসি শিক্ষার্থীদের আইসিটি বিষয়ের প্রোগ্রামিং অংশের অনুশীলনের জন্য ডিজাইন করা হয়েছে। অ্যাপটি ইন্টারনেট কানেকশন ছাড়াই শিক্ষার্থীদের স্মার্টফোনে কিংবা কম্পিউটারে প্রোগ্রামিং চর্চা করার পরিবেশ প্রদান করে।
                  </p>
                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-2 text-sm uppercase tracking-wide">মূল ফিচারসমূহ:</h4>
                    <ul className="list-disc pl-5 space-y-1.5 text-xs">
                      <li><strong>অফলাইন কোড এক্সিকিউশন:</strong> ইন্টারনেট ছাড়াই C, Python এবং SQLite SQL কোড রান করুন।</li>
                      <li><strong>স্মার্ট বাংলা এরর এক্সপ্লেনেশন:</strong> কম্পাইলার ভুল করলে তা বাংলায় ব্যাখ্যা করে সহজ পরামর্শ দেয়।</li>
                      <li><strong>প্রফেশনাল কোড এডিটর:</strong> লাইন নম্বর, ব্র্যাকেট অটো-পেয়ারিং, কাস্টম ইনডেন্টেশন এবং সার্চ/রিপ্লেস সাপোর্ট।</li>
                      <li><strong>পেইড গ্রেড ইউআই ও থিমসমূহ:</strong> One Dark Pro এবং GitHub Light থিমের সমন্বয়ে দৃষ্টিনন্দন ডিজাইন।</li>
                      <li><strong>প্রজেক্ট ম্যানেজমেন্ট:</strong> প্রজেক্ট তৈরি, রিনেম, ডুপ্লিকেট, আর্কাইভ এবং ZIP ফাইল এক্সপোর্ট-ইম্পোর্ট করার সুবিধা।</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-2 text-sm uppercase tracking-wide">আমাদের মিশন ও ভিশন:</h4>
                    <p className="text-xs">
                      <strong>মিশন:</strong> বাংলাদেশের প্রত্যন্ত অঞ্চলের শিক্ষার্থীদের জন্য আধুনিক প্রযুক্তি শিক্ষা ও কোডিং চর্চাকে কোনো ইন্টারনেটের ঝামেলা ছাড়াই সম্পূর্ণ সহজ এবং সহজবোধ্য উপায়ে পৌঁছে দেওয়া।<br />
                      <strong>ভিশন:</strong> প্রতিটি এইচএসসি শিক্ষার্থীর আইসিটি ব্যবহারিক পরীক্ষা এবং আইটি ক্যারিয়ার ফাউন্ডেশনের সবচেয়ে বিশ্বস্ত ও নির্ভরযোগ্য সহযোগী হয়ে গড়ে ওঠা।
                    </p>
                  </div>

                  <div className="pt-2 border-t border-gray-100 dark:border-gray-800 text-xs font-mono text-gray-400">
                    <p>স্ট্যাক: React • TypeScript • Vite • Tailwind CSS • Drift Engine</p>
                    <p>সংস্করণ: v2.1.0 (রিলিজ ২৬-০৬-২০২৬)</p>
                  </div>
                </div>
              </div>
            )}

            {/* --- Render "Privacy Policy" --- */}
            {subView === 'privacy' && (
              <div className="space-y-4 text-justify" id="privacy-page">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-100 dark:border-gray-800">
                  <ShieldCheck className="h-5.5 w-5.5 text-green-500" />
                  <h2 className="text-lg font-bold">প্রাইভেসি পলিসি (Privacy Policy)</h2>
                </div>
                <div className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed space-y-3.5">
                  <p>
                    আপনার তথ্যের গোপনীয়তা রক্ষা করা কোডশালা-র সর্বোচ্চ অগ্রাধিকার। যেহেতু কোডশালা একটি অফলাইন-ফার্স্ট অ্যাপ্লিকেশন, তাই আপনার অধিকাংশ ডাটা এবং তৈরি করা ফাইল সম্পূর্ণ নিরাপদভাবে আপনার নিজের ডিভাইসেই জমা থাকে।
                  </p>
                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">১. আমরা যেসব ডাটা সংগ্রহ করতে পারি</h4>
                    <p>সাধারণ ব্যবহারের জন্য কোডশালা-র কোনো অ্যাকাউন্টের বা ব্যক্তিগত তথ্যের প্রয়োজন হয় না। তবে অ্যাপে আপনার ব্যক্তিগত সেটিংস সুরক্ষায় নিম্নোক্ত ডাটাগুলো লোকাল ক্যাশে/স্টোরেজে সংরক্ষিত থাকে:</p>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>আপনার তৈরি প্রোগ্রামিং প্রজেক্ট ও ফাইলসমূহ।</li>
                      <li>এডিটর প্রেফারেন্স (ফন্ট সাইজ, এডিটর থিম ইত্যাদি)।</li>
                      <li>অ্যাপ থিম সেটিংস এবং অটো-সেভ হিস্ট্রি।</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">২. লোকাল স্টোরেজ ও নিরাপত্তা</h4>
                    <p>আপনার কোড এবং প্রজেক্টের ডাটা ডিভাইসের লোকাল স্টোরেজে (localStorage/IndexedDB) অত্যন্ত সুরক্ষিতভাবে সংরক্ষিত থাকে। ডাটা ক্লিয়ার বা হিস্ট্রি ডিলিট না করলে এগুলো চিরকাল আপনার কাছে সংরক্ষিত থাকবে। কোনো ক্লাউড সার্ভারে এগুলো আপনার অনুমতি ব্যতীত পাঠানো হয় না।</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">৩. ইন্টারনেটের ব্যবহার</h4>
                    <p>অ্যাপটি সম্পূর্ণ অফলাইনে কাজ করে। তবে নিচের সাধারণ কাজের জন্য সামান্য ইন্টারনেট ব্যবহৃত হতে পারে:</p>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>অনলাইন কম্পাইলার চেক করা (বিকল্প হিসেবে Judge0 API ইন্টিগ্রেশন)।</li>
                      <li>অ্যাপের লেটেস্ট আপডেট ও শেখার রিসোর্স চেক করার জন্য।</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">৪. চিলড্রেন প্রাইভেসি</h4>
                    <p>কোডশালা একটি শিক্ষামূলক অ্যাপ। সব বয়সের শিক্ষার্থী বিশেষ করে স্কুল-কলেজের ছাত্র-ছাত্রীরা এটি নিরাপদে ব্যবহার করতে পারে। আমরা অপ্রাপ্তবয়স্ক বা কোনো ব্যবহারকারীর কোনো গোপন তথ্য ট্র্যাক বা হোস্ট করি না।</p>
                  </div>

                  <p className="text-[10px] text-gray-400">সর্বশেষ আপডেট: ২৬ জুন, ২০২৬</p>
                </div>
              </div>
            )}

            {/* --- Render "Terms & Conditions" --- */}
            {subView === 'terms' && (
              <div className="space-y-4 text-justify" id="terms-page">
                <div className="flex items-center gap-2 pb-2 border-b border-gray-100 dark:border-gray-800">
                  <FileText className="h-5.5 w-5.5 text-cyan-500" />
                  <h2 className="text-lg font-bold">শর্তাবলী ও নিয়মাবলি (Terms and Conditions)</h2>
                </div>
                <div className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed space-y-3.5">
                  <p>
                    কোডশালা অ্যাপ্লিকেশনটি ব্যবহারের ক্ষেত্রে নিম্নলিখিত শর্তাবলী প্রযোজ্য হবে। অ্যাপটি ব্যবহার শুরু করার মাধ্যমে আপনি এই শর্তগুলোতে সম্মতি প্রদান করছেন।
                  </p>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">১. শিক্ষামূলক উদ্দেশ্যে ব্যবহার</h4>
                    <p>কোডশালা শুধুমাত্র একাডেমিক, ব্যক্তিগত শিক্ষা এবং অনুশীলনের জন্য ব্যবহার করা যাবে। কোনো অসৎ বা ক্ষতিকারক উদ্দেশ্যে (যেমন সিস্টেমে ম্যালিসিয়াস কোড ইনজেক্ট করা বা সার্ভারে অবৈধ অ্যাটাক পাঠানো) এর ব্যবহার সম্পূর্ণ নিষিদ্ধ।</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">২. ব্যবহারকারীর দায়বদ্ধতা</h4>
                    <p>আপনার তৈরি করা প্রজেক্ট, স্ক্রিপ্ট এবং ফাইলগুলোর সম্পূর্ণ মালিকানা ও নিরাপত্তা আপনার নিজের। ডিভাইস পরিবর্তন বা ব্রাউজার ডাটা রিসেট করার ফলে কোড হারিয়ে গেলে কোডশালা বা এর ডেভেলপার দায়ী থাকবে না। তাই নিয়মিত ব্যাকআপ নিতে ZIP এক্সপোর্ট ব্যবহার করুন।</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">৩. মেধাস্বত্ব ও কপিরাইট</h4>
                    <p>কোডশালা-র ইন্টারফেস ডিজাইন, লোগো, ব্র্যান্ডিং এবং সোর্স কোড সম্পূর্ণভাবে কোডশালা-র মালিকানাধীন। তবে শিক্ষার্থীরা তাদের তৈরি করা কোড যেকোনো কাজে স্বাধীনভাবে ব্যবহারের পূর্ণ অধিকার ধারণ করেন।</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-800 dark:text-white mb-1.5">৪. ওয়ারেন্টি ও লাইবিলিটি লিমিটেশন</h4>
                    <p>অ্যাপ্লিকেশনটি "As Is" (যেভাবে আছে) ভিত্তিতে কোনো প্রকার ওয়ারেন্টি ছাড়াই দেওয়া হয়েছে। সর্বোচ্চ প্রচেষ্টা থাকা সত্ত্বেও কোনো ডিভাইসে পারফরম্যান্সের তারতম্য বা কোড রানিংয়ের সাময়িক জটিলতা সৃষ্টি হতে পারে, যার জন্য ডেভেলপার দায়ী নন।</p>
                  </div>

                  <p className="text-[10px] text-gray-400">যেকোনো প্রশ্ন বা ফিডব্যাকের জন্য ডেভেলপার পেজে যোগাযোগ করুন।</p>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Embedded About Developer dialog */}
      <AboutDeveloperDialog 
        isOpen={isDevDialogOpen} 
        onClose={() => setIsDevDialogOpen(false)} 
      />
    </div>
  );
}
