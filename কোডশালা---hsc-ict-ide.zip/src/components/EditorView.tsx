/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  RotateCcw, 
  RotateCw, 
  Search, 
  ZoomIn, 
  ZoomOut, 
  Save, 
  ArrowLeft, 
  Layout, 
  ChevronRight, 
  Replace, 
  Terminal, 
  Database, 
  Code,
  Sliders,
  Sparkles,
  RefreshCw,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Project, Settings, CompilerResult, Language } from '../types';
import QuickToolbar from './QuickToolbar';

interface EditorViewProps {
  project: Project;
  settings: Settings;
  onUpdateCode: (code: string) => void;
  onRunCode: (code: string) => Promise<CompilerResult>;
  onBackToDashboard: () => void;
  onOpenOutputPanel: (result: CompilerResult) => void;
  isCompiling: boolean;
}

export default function EditorView({
  project,
  settings,
  onUpdateCode,
  onRunCode,
  onBackToDashboard,
  onOpenOutputPanel,
  isCompiling
}: EditorViewProps) {
  const [code, setCode] = useState(project.code);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const highlightRef = useRef<HTMLPreElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  // Undo / Redo History
  const [history, setHistory] = useState<string[]>([project.code]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Search & Replace Drawer
  const [showSearch, setShowSearch] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [replaceTerm, setReplaceTerm] = useState('');
  const [searchMatches, setSearchMatches] = useState<number[]>([]); // indexes

  // Cursor Status
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });

  // Sync internal state when project changes
  useEffect(() => {
    setCode(project.code);
    setHistory([project.code]);
    setHistoryIndex(0);
  }, [project.id]);

  // Synchronize scrolling between the textarea and highlight container
  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    const { scrollTop, scrollLeft } = e.currentTarget;
    if (highlightRef.current) {
      highlightRef.current.scrollTop = scrollTop;
      highlightRef.current.scrollLeft = scrollLeft;
    }
    if (lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = scrollTop;
    }
  };

  // Tracking Cursor Coordinates
  const updateCursorPosition = (e: React.SyntheticEvent<HTMLTextAreaElement>) => {
    const target = e.currentTarget;
    const value = target.value;
    const selStart = target.selectionStart;

    const sub = value.substring(0, selStart);
    const lines = sub.split('\n');
    setCursorPos({
      line: lines.length,
      col: lines[lines.length - 1].length + 1
    });
  };

  // Auto-pairing brackets and auto-indentation handler
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const value = textarea.value;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;

    // 1. Bracket/Quote pairing
    const pairs: Record<string, string> = {
      '{': '}',
      '[': ']',
      '(': ')',
      '"': '"',
      "'": "'"
    };

    if (pairs[e.key] !== undefined) {
      e.preventDefault();
      const closingChar = pairs[e.key];
      const newValue = value.substring(0, start) + e.key + closingChar + value.substring(end);
      
      setCode(newValue);
      onUpdateCode(newValue);
      pushHistory(newValue);

      // Restore cursor position inside the brackets
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 1;
      }, 0);
      return;
    }

    // 2. Tab key support (inserts 4 spaces instead of moving focus)
    if (e.key === 'Tab') {
      e.preventDefault();
      const newValue = value.substring(0, start) + '    ' + value.substring(end);
      setCode(newValue);
      onUpdateCode(newValue);
      pushHistory(newValue);

      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 4;
      }, 0);
      return;
    }

    // 3. Smart Indentation on pressing Enter
    if (e.key === 'Enter') {
      e.preventDefault();
      
      // Get the current line's text up to the cursor
      const beforeCursor = value.substring(0, start);
      const lines = beforeCursor.split('\n');
      const currentLine = lines[lines.length - 1];

      // Match the leading spaces (whitespace/indentation)
      const indentMatch = currentLine.match(/^ */);
      let indent = indentMatch ? indentMatch[0] : '';

      // If previous statement opens a scope, add 4 extra spaces
      const trimmedLine = currentLine.trim();
      if (trimmedLine.endsWith('{') || trimmedLine.endsWith(':')) {
        indent += '    ';
      }

      const newValue = value.substring(0, start) + '\n' + indent + value.substring(end);
      setCode(newValue);
      onUpdateCode(newValue);
      pushHistory(newValue);

      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 1 + indent.length;
      }, 0);
      return;
    }
  };

  // Add a state snapshot to history for Undo/Redo
  const pushHistory = (newCode: string) => {
    // Avoid duplicates
    if (history[historyIndex] === newCode) return;

    const truncatedHistory = history.slice(0, historyIndex + 1);
    const newHistory = [...truncatedHistory, newCode];
    
    // Limit history stack size to 50
    if (newHistory.length > 50) {
      newHistory.shift();
    }
    
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const prevIdx = historyIndex - 1;
      setHistoryIndex(prevIdx);
      const prevCode = history[prevIdx];
      setCode(prevCode);
      onUpdateCode(prevCode);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextIdx = historyIndex + 1;
      setHistoryIndex(nextIdx);
      const nextCode = history[nextIdx];
      setCode(nextCode);
      onUpdateCode(nextCode);
    }
  };

  // Quick toolbar symbols inserter
  const handleInsertSymbol = (sym: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const val = textarea.value;

    let before = val.substring(0, start);
    let after = val.substring(end);

    let offset = 1;
    let insertStr = sym;

    // If double symbol e.g {}, let cursor stay inside
    if (sym === '{}' || sym === '[]' || sym === '()' || sym === '<>') {
      insertStr = sym;
      offset = 1;
    } else {
      offset = sym.length;
    }

    const newValue = before + insertStr + after;
    setCode(newValue);
    onUpdateCode(newValue);
    pushHistory(newValue);

    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + offset;
    }, 50);
  };

  // Textarea updates
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setCode(val);
    onUpdateCode(val);

    // Throttled history log on word space boundaries to keep history useful
    if (val.endsWith(' ') || val.endsWith('\n')) {
      pushHistory(val);
    }
  };

  const handleTriggerRun = async () => {
    // Save first
    onUpdateCode(code);
    const res = await onRunCode(code);
    onOpenOutputPanel(res);
  };

  // Search & Replace logic
  const handleSearch = () => {
    if (!searchTerm) {
      setSearchMatches([]);
      return;
    }
    const escapedSearch = searchTerm.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(escapedSearch, 'g');
    const matches: number[] = [];
    let match;
    while ((match = regex.exec(code)) !== null) {
      matches.push(match.index);
    }
    setSearchMatches(matches);
  };

  const handleReplace = () => {
    if (!searchTerm) return;
    const escapedSearch = searchTerm.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(escapedSearch, 'g');
    const replaced = code.replace(regex, replaceTerm);
    setCode(replaced);
    onUpdateCode(replaced);
    pushHistory(replaced);
    setSearchMatches([]);
  };

  // --------------------------------------------------
  // High-performance Syntax Highlighting Rules Regex
  // --------------------------------------------------
  const highlightCode = (source: string, lang: Language) => {
    // Escape standard HTML tags in code
    let html = source
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    const isDark = settings.editorTheme === 'one-dark';

    // Theme color definitions
    const colors = isDark ? {
      keyword: 'text-[#61AFEF] font-bold',
      builtin: 'text-[#E5C07B] font-medium',
      directive: 'text-[#E06C75] font-semibold',
      string: 'text-[#98C379] font-mono',
      number: 'text-[#D19A66] font-mono',
      comment: 'text-[#7F848E] italic font-sans',
      tag: 'text-[#E06C75] font-bold',
      attr: 'text-[#D19A66] font-mono'
    } : {
      keyword: 'text-[#005CC5] font-bold',
      builtin: 'text-[#6F42C1] font-medium',
      directive: 'text-[#D73A49] font-semibold',
      string: 'text-[#22863A] font-mono',
      number: 'text-[#005CC5] font-mono',
      comment: 'text-[#6A737D] italic font-sans',
      tag: 'text-[#22863A] font-bold',
      attr: 'text-[#E36209] font-mono'
    };

    if (lang === 'c') {
      // Directives
      html = html.replace(/(#include\s+&lt;[^&]+&gt;|#define\s+[A-Za-z0-9_]+)/g, `<span class="${colors.directive}">$1</span>`);
      // Keywords
      html = html.replace(/\b(int|float|double|char|long|unsigned|void|return|if|else|for|while|do|switch|case|default|break|continue|struct|typedef|const)\b/g, `<span class="${colors.keyword}">$1</span>`);
      // Numbers
      html = html.replace(/\b([0-9]+(?:\.[0-9]+)?)\b/g, `<span class="${colors.number}">$1</span>`);
      // Builtins
      html = html.replace(/\b(main|printf|scanf|pow|sqrt|abs)\b/g, `<span class="${colors.builtin}">$1</span>`);
      // String Literals
      html = html.replace(/(&quot;[^&]*&quot;)/g, `<span class="${colors.string}">$1</span>`);
      // Line Comments
      html = html.replace(/(\/\/.*)/g, `<span class="${colors.comment}">$1</span>`);
    }

    if (lang === 'python') {
      // Keywords
      html = html.replace(/\b(def|class|if|elif|else|for|while|in|import|from|as|return|break|continue|and|or|not|is|None|True|False|try|except)\b/g, `<span class="${colors.keyword}">$1</span>`);
      // Builtins
      html = html.replace(/\b(print|input|int|float|str|len|range|list|dict|set|abs|pow|round)\b/g, `<span class="${colors.builtin}">$1</span>`);
      // Numbers
      html = html.replace(/\b([0-9]+(?:\.[0-9]+)?)\b/g, `<span class="${colors.number}">$1</span>`);
      // String Literals (Double or single quotes)
      html = html.replace(/(&quot;[^&]*&quot;|'[^']*')/g, `<span class="${colors.string}">$1</span>`);
      // Comments
      html = html.replace(/(#.*)/g, `<span class="${colors.comment}">$1</span>`);
    }

    if (lang === 'sql') {
      // Keywords
      html = html.replace(/\b(CREATE|TABLE|PRIMARY|KEY|INSERT|INTO|VALUES|SELECT|FROM|WHERE|ORDER|BY|GROUP|ASC|DESC|INT|REAL|TEXT|FOREIGN|REFERENCES|NOT|NULL|AND|OR)\b/gi, `<span class="${colors.keyword}">$1</span>`);
      // Numbers
      html = html.replace(/\b([0-9]+(?:\.[0-9]+)?)\b/g, `<span class="${colors.number}">$1</span>`);
      // SQL Strings
      html = html.replace(/'([^']*)'/g, `<span class="${colors.string}">'$1'</span>`);
      // Comments
      html = html.replace(/(--.*)/g, `<span class="${colors.comment}">$1</span>`);
    }

    if (lang === 'html') {
      // HTML Tags
      html = html.replace(/(&lt;\/?[a-zA-Z0-9-]+(?:\s+[^&]*)?&gt;)/g, `<span class="${colors.tag}">$1</span>`);
      // Tag Attributes
      html = html.replace(/(\s+[a-zA-Z0-9-]+)=(&quot;[^&]*&quot;|'[^']*')/g, `$1=<span class="${colors.attr}">$2</span>`);
      // HTML Comments
      html = html.replace(/(&lt;!--[\s\S]*?--&gt;)/g, `<span class="${colors.comment}">$1</span>`);
    }

    return html;
  };

  // Generate dynamic line numbers based on text line splits
  const lineNumbers = code.split('\n').map((_, index) => index + 1);

  const handleWorkspaceClick = () => {
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#fafafc] dark:bg-[#090909] overflow-hidden" id="editor-view-container">
      {/* 1. IDE Header Controls */}
      <div className="flex items-center justify-between px-4 py-3 bg-white dark:bg-[#151515] border-b border-gray-100 dark:border-gray-800 shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={onBackToDashboard}
            className="p-1.5 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 transition-colors cursor-pointer"
            id="editor-back-to-dashboard-btn"
          >
            <ArrowLeft className="h-4.5 w-4.5" />
          </button>
          <div className="flex flex-col text-left font-sans">
            <h3 className="font-bold text-gray-900 dark:text-white leading-none text-sm">{project.name}</h3>
            <span className="text-[10px] text-gray-400 dark:text-gray-500 font-mono uppercase mt-0.5">{project.language} IDE</span>
          </div>
        </div>

        {/* Toolbar Buttons */}
        <div className="flex items-center gap-1">
          {/* Undo */}
          <button
            onClick={handleUndo}
            disabled={historyIndex === 0}
            className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-20 cursor-pointer"
            title="পূর্বাবস্থায় ফিরুন (Undo)"
            id="editor-undo-btn"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
          
          {/* Redo */}
          <button
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-20 cursor-pointer"
            title="পুনরায় করুন (Redo)"
            id="editor-redo-btn"
          >
            <RotateCw className="h-4 w-4" />
          </button>

          <div className="w-px h-4 bg-gray-200 dark:bg-gray-800 mx-1" />

          {/* Search Toggle */}
          <button
            onClick={() => setShowSearch(!showSearch)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${showSearch ? 'bg-[#4F7DF7]/10 text-[#4F7DF7] dark:bg-[#6EA8FE]/10 dark:text-[#6EA8FE]' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
            title="খুঁজুন ও প্রতিস্থাপন (Search)"
            id="editor-search-toggle"
          >
            <Search className="h-4 w-4" />
          </button>

          <div className="w-px h-4 bg-gray-200 dark:bg-gray-800 mx-1" />

          {/* RUN BUTTON */}
          <button
            onClick={handleTriggerRun}
            disabled={isCompiling}
            className="inline-flex items-center gap-1 rounded-xl bg-green-500 text-white font-sans font-bold px-4.5 py-2 text-xs hover:bg-green-600 active:scale-95 disabled:bg-gray-300 disabled:text-gray-500 transition-all cursor-pointer"
            id="editor-run-btn"
          >
            {isCompiling ? (
              <>
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                <span>রানিং...</span>
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5 fill-white stroke-none" />
                <span>রান করুন</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. Floating Search Drawer */}
      <AnimatePresence>
        {showSearch && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-white dark:bg-[#1E1E1E] border-b border-gray-100 dark:border-gray-800 px-4 py-2 flex flex-wrap items-center gap-2 text-xs font-sans shrink-0 overflow-hidden"
            id="search-replace-drawer"
          >
            <div className="flex items-center gap-1.5 flex-1 min-w-[150px]">
              <span className="text-gray-400 font-semibold uppercase">খুঁজুন:</span>
              <input
                type="text"
                placeholder="যেমন: sum"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyUp={handleSearch}
                className="flex-1 bg-gray-50 dark:bg-[#090909] border border-gray-200 dark:border-gray-800 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 dark:text-white focus:outline-none focus:border-[#4F7DF7]"
                id="search-input"
              />
            </div>
            
            <div className="flex items-center gap-1.5 flex-1 min-w-[150px]">
              <span className="text-gray-400 font-semibold uppercase">প্রতিস্থাপন:</span>
              <input
                type="text"
                placeholder="যেমন: total"
                value={replaceTerm}
                onChange={(e) => setReplaceTerm(e.target.value)}
                className="flex-1 bg-gray-50 dark:bg-[#090909] border border-gray-200 dark:border-gray-800 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 dark:text-white focus:outline-none focus:border-[#4F7DF7]"
                id="replace-input"
              />
            </div>

            <div className="flex gap-1.5">
              <button
                onClick={handleReplace}
                className="rounded-lg bg-[#4F7DF7] text-white px-3 py-1.5 font-bold hover:bg-opacity-95 dark:bg-[#6EA8FE] dark:text-[#090909]"
                id="replace-execute-btn"
              >
                বদলান
              </button>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setReplaceTerm('');
                  setSearchMatches([]);
                  setShowSearch(false);
                }}
                className="p-1.5 rounded-lg border border-gray-200 text-gray-400 dark:border-gray-800"
                id="replace-cancel-btn"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. Editor Editor Panel (Synced text area overlay over custom highlighted tag) */}
      <div 
        className="flex-1 flex overflow-hidden relative min-h-0" 
        id="editor-workspace"
        onClick={handleWorkspaceClick}
      >
        
        {/* Line Numbers column */}
        <div 
          ref={lineNumbersRef}
          className={`w-12 select-none text-right pr-2.5 py-4 font-mono text-xs border-r overflow-hidden transition-colors duration-300 ${settings.editorTheme === 'one-dark' ? 'bg-[#151515] border-[#252525] text-[#5c6370]' : 'bg-[#fafafa] border-gray-100 text-gray-400'}`}
          id="editor-line-numbers"
        >
          {lineNumbers.map((num) => (
            <div key={num} className="h-5 leading-5 select-none">{num}</div>
          ))}
        </div>

        {/* Textarea Overlay and Highlight Area */}
        <div 
          className={`flex-1 h-full relative overflow-hidden min-h-0 min-w-0 transition-colors duration-300 ${settings.editorTheme === 'one-dark' ? 'bg-[#1e1e1e] text-[#abb2bf]' : 'bg-white text-gray-800'}`} 
          id="editor-canvas-container"
          onClick={handleWorkspaceClick}
        >
          {/* Dual Layer 1: Highlighting Display (Underlay) */}
          <pre
            ref={highlightRef}
            className={`absolute inset-0 m-0 p-4 font-mono text-xs pointer-events-none select-none whitespace-pre overflow-auto scrollbar-none z-10 leading-5 ${settings.editorTheme === 'one-dark' ? 'text-[#abb2bf]' : 'text-gray-800'}`}
            aria-hidden="true"
            id="editor-syntax-underlay"
          >
            <code
              className="block"
              style={{ fontSize: `${settings.fontSize}px` }}
              dangerouslySetInnerHTML={{ __html: highlightCode(code, project.language) }}
            />
          </pre>

          {/* Dual Layer 2: Real Interactor Input (Overlay) */}
          <textarea
            ref={textareaRef}
            value={code}
            onChange={handleTextareaChange}
            onScroll={handleScroll}
            onKeyDown={handleKeyDown}
            onSelect={updateCursorPosition}
            onKeyUp={updateCursorPosition}
            className={`absolute inset-0 w-full h-full p-4 font-mono text-xs resize-none outline-none overflow-auto leading-5 z-20 whitespace-pre scrollbar-thin ${settings.editorTheme === 'one-dark' ? 'caret-white text-transparent' : 'caret-gray-900 text-transparent'}`}
            spellCheck="false"
            id="editor-textarea-overlay"
            style={{ 
              fontSize: `${settings.fontSize}px`,
              background: 'transparent',
              color: 'transparent',
              WebkitTextFillColor: 'transparent',
            }}
          />
        </div>
      </div>

      {/* 4. Scrolling QuickAccess symbol toolbar */}
      <QuickToolbar language={project.language} onInsertSymbol={handleInsertSymbol} />

      {/* 5. Status / Footer Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-white dark:bg-[#151515] border-t border-gray-100 dark:border-gray-800 text-[11px] text-gray-400 dark:text-gray-500 shrink-0 font-sans select-none">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 font-medium">
            <span className="h-1.5 w-1.5 rounded-full bg-green-500" />
            <span>অফলাইন কম্পাইলার সচল</span>
          </span>
          <span>•</span>
          <span className="font-mono">
            ভাষা: <strong className="uppercase">{project.language}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2 font-mono" id="cursor-pos-display">
          <span>লাইন: {cursorPos.line}</span>
          <span>,</span>
          <span>কলাম: {cursorPos.col}</span>
        </div>
      </div>
    </div>
  );
}
