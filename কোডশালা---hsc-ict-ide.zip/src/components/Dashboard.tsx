/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  FolderOpen, 
  Archive, 
  MoreVertical, 
  Edit2, 
  Copy, 
  Trash2, 
  Share2, 
  Download, 
  Upload, 
  Terminal, 
  Database, 
  Code, 
  Sparkles,
  BookOpen,
  Calendar,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Project, Language } from '../types';

interface DashboardProps {
  projects: Project[];
  onCreateProject: (name: string, language: Language, initialCode?: string) => void;
  onSelectProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onRenameProject: (id: string, newName: string) => void;
  onDuplicateProject: (id: string) => void;
  onArchiveProject: (id: string) => void;
  onImportBackup: (backupStr: string) => void;
}

export default function Dashboard({
  projects,
  onCreateProject,
  onSelectProject,
  onDeleteProject,
  onRenameProject,
  onDuplicateProject,
  onArchiveProject,
  onImportBackup
}: DashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguageFilter, setSelectedLanguageFilter] = useState<'all' | Language>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newProjName, setNewProjName] = useState('');
  const [newProjLang, setNewProjLang] = useState<Language>('c');
  
  // Project management context menus
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [renamingProjectId, setRenamingProjectId] = useState<string | null>(null);
  const [renamingName, setRenamingName] = useState('');

  // 1. Time-based Bengali Greeting
  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'শুভ সকাল';
    if (hour >= 12 && hour < 17) return 'শুভ দুপুর';
    if (hour >= 17 && hour < 20) return 'শুভ সন্ধ্যা';
    return 'শুভ রাত্রি';
  }, []);

  // 2. Today's learning progress simulation
  // We can calculate progress as how many projects exist (max 8)
  const progressPercent = useMemo(() => {
    const activeCount = projects.filter(p => !p.isArchived).length;
    return Math.min(100, Math.round((activeCount / 8) * 100));
  }, [projects]);

  const progressMsg = useMemo(() => {
    const activeCount = projects.filter(p => !p.isArchived).length;
    if (activeCount === 0) return 'আজ এখনো কোনো প্রজেক্ট তৈরি করা হয়নি। শুরু করতে নিচের যেকোনো একটি ভাষায় ক্লিক করুন!';
    if (activeCount < 3) return 'খুব ভালো শুরু! আপনার প্রজেক্টগুলো রান করে কোডিং শিখুন।';
    if (activeCount < 6) return 'অসাধারণ গতি! আপনি দারুণভাবে আইসিটি লার্নিং প্র্যাকটিস করছেন।';
    return 'দুর্দান্ত! আপনি আজকের আইসিটি লার্নিং লক্ষ্যের ১০০% পূরণ করেছেন!';
  }, [projects]);

  // 3. Last opened/updated project
  const lastOpenedProject = useMemo(() => {
    if (projects.length === 0) return null;
    const sorted = [...projects].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    return sorted[0];
  }, [projects]);

  // 4. Filtering and searching
  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesLang = selectedLanguageFilter === 'all' || p.language === selectedLanguageFilter;
      return matchesSearch && matchesLang;
    });
  }, [projects, searchQuery, selectedLanguageFilter]);

  // Handle backup file upload
  const handleBackupUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        onImportBackup(text);
      }
    };
    reader.readAsText(file);
  };

  // Export all projects as a single backup JSON
  const handleExportBackup = () => {
    const backupData = JSON.stringify(projects, null, 2);
    const blob = new Blob([backupData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `codeshala-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const submitCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;
    
    // Choose blank starter code based on language
    let code = '';
    if (newProjLang === 'c') {
      code = `#include <stdio.h>\n\nint main() {\n    printf("হ্যালো ওয়ার্ল্ড!\\n");\n    return 0;\n}`;
    } else if (newProjLang === 'python') {
      code = `print("হ্যালো ওয়ার্ল্ড!")\n`;
    } else if (newProjLang === 'sql') {
      code = `CREATE TABLE Students (\n    Roll INT PRIMARY KEY,\n    Name TEXT,\n    GPA REAL\n);\n\nINSERT INTO Students VALUES (1, 'কামাল', 5.0);\n\nSELECT * FROM Students;`;
    } else if (newProjLang === 'html') {
      code = `<!DOCTYPE html>\n<html>\n<head>\n    <title>কোডশালা এইচটিএমএল প্রজেক্ট</title>\n    <style>\n        body {\n            font-family: Arial, sans-serif;\n            text-align: center;\n            padding-top: 50px;\n            background-color: #f0f4f8;\n        }\n        h1 {\n            color: #4F7DF7;\n        }\n    </style>\n</head>\n<body>\n    <h1>হ্যালো ওয়ার্ল্ড!</h1>\n    <p>কোডশালা অফলাইন ওয়েব এডিটরে আপনাকে স্বাগতম।</p>\n</body>\n</html>`;
    }

    onCreateProject(newProjName.trim(), newProjLang, code);
    setNewProjName('');
    setShowCreateModal(false);
  };

  const handleShareProject = (p: Project) => {
    const text = `কোডশালা আইসিটি আইডিই থেকে প্রজেক্ট: "${p.name}" (${p.language.toUpperCase()})\n\n소스 কোড:\n${p.code}\n\nডাউনলোড করুন কোডশালা অ্যাপ।`;
    if (navigator.share) {
      navigator.share({
        title: p.name,
        text: text
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(p.code);
      alert(`কোড ক্লিপবোর্ডে কপি হয়েছে! আপনি এখন এটি যেকোনো জায়গায় শেয়ার করতে পারবেন।`);
    }
  };

  return (
    <div className="space-y-6 font-sans text-gray-800 dark:text-gray-100" id="dashboard-container">
      {/* 1. Header Greeting Panel */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-br from-[#4F7DF7]/5 to-transparent dark:from-[#6EA8FE]/5 dark:to-transparent rounded-[28px] p-6 border border-gray-100/50 dark:border-gray-800/20" id="dashboard-header">
        <div className="space-y-1">
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white">
            {greeting}, শিক্ষার্থী! 👋
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">
            আজকের আইসিটি লার্নিং ও কোডিং প্র্যাকটিস সেশনে আপনাকে স্বাগতম।
          </p>
        </div>

        {/* Create and Import buttons */}
        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-1.5 rounded-2xl bg-[#4F7DF7] px-4.5 py-3 text-sm font-semibold text-white hover:bg-opacity-95 active:scale-98 transition-all dark:bg-[#6EA8FE] dark:text-[#090909] shadow-sm cursor-pointer"
            id="create-new-project-btn"
          >
            <Plus className="h-4.5 w-4.5 stroke-[2.5]" />
            <span>নতুন প্রজেক্ট তৈরি করুন</span>
          </button>

          <label
            className="inline-flex items-center gap-1.5 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-[#151515] px-4 py-3 text-sm font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 active:scale-98 transition-all shadow-sm cursor-pointer"
            id="import-backup-label"
          >
            <Upload className="h-4.5 w-4.5 text-gray-500" />
            <span>ইম্পোর্ট (JSON)</span>
            <input
              type="file"
              accept=".json"
              onChange={handleBackupUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* 2. Bento Grid of Progress and Continue Card */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5" id="dashboard-bento">
        {/* Today's Learning progress - Radial Dial */}
        <div className="md:col-span-5 bg-white dark:bg-[#151515] rounded-[22px] p-5 shadow-[0_4px_20px_rgba(0,0,0,0.015)] border border-gray-100 dark:border-gray-800 flex items-center gap-5">
          {/* Circular Progress Ring */}
          <div className="relative h-20 w-20 shrink-0">
            <svg className="h-20 w-20 -rotate-90">
              <circle
                cx="40"
                cy="40"
                r="34"
                className="stroke-gray-100 dark:stroke-gray-800"
                strokeWidth="7"
                fill="transparent"
              />
              <circle
                cx="40"
                cy="40"
                r="34"
                className="stroke-[#4F7DF7] dark:stroke-[#6EA8FE] transition-all duration-1000"
                strokeWidth="7"
                fill="transparent"
                strokeDasharray={`${2 * Math.PI * 34}`}
                strokeDashoffset={`${2 * Math.PI * 34 * (1 - progressPercent / 100)}`}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center font-sans">
              <span className="text-base font-black tracking-tighter text-gray-900 dark:text-white" id="progress-percent">
                {progressPercent}%
              </span>
              <span className="text-[9px] font-bold text-gray-400 uppercase leading-none">পূর্ণ</span>
            </div>
          </div>

          <div className="space-y-1 font-sans">
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#4F7DF7] dark:text-[#6EA8FE] uppercase tracking-wide">
              <Calendar className="h-3 w-3" />
              <span>দৈনিক শিক্ষা অগ্রগতি</span>
            </span>
            <h4 className="text-sm font-bold text-gray-800 dark:text-white leading-tight">লক্ষ্যমাত্রা ট্র্যাকার</h4>
            <p className="text-xs text-gray-500 dark:text-gray-400 leading-normal" id="progress-message">
              {progressMsg}
            </p>
          </div>
        </div>

        {/* Continue Project */}
        <div className="md:col-span-7 bg-white dark:bg-[#151515] rounded-[22px] p-5 shadow-[0_4px_20px_rgba(0,0,0,0.015)] border border-gray-100 dark:border-gray-800 flex flex-col justify-between">
          {lastOpenedProject ? (
            <>
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-green-500 uppercase tracking-wide">
                    <Sparkles className="h-3 w-3" />
                    <span>প্রজেক্ট চালিয় যান</span>
                  </span>
                  <h3 className="text-base font-bold text-gray-900 dark:text-white line-clamp-1" id="continue-project-name">
                    {lastOpenedProject.name}
                  </h3>
                  <p className="text-xs text-gray-400 dark:text-gray-500 font-mono">
                    সর্বশেষ আপডেট: {new Date(lastOpenedProject.updatedAt).toLocaleTimeString('bn-BD', { hour: 'numeric', minute: '2-digit' })}
                  </p>
                </div>

                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-50 dark:bg-[#1E1E1E]">
                  {lastOpenedProject.language === 'c' && <Code className="h-5 w-5 text-blue-500" />}
                  {lastOpenedProject.language === 'python' && <Terminal className="h-5 w-5 text-yellow-500" />}
                  {lastOpenedProject.language === 'sql' && <Database className="h-5 w-5 text-teal-500" />}
                  {lastOpenedProject.language === 'html' && <Layers className="h-5 w-5 text-red-500" />}
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-gray-100 dark:border-gray-800 pt-3 mt-4">
                <span className="text-xs text-gray-500 dark:text-gray-400 font-sans">
                  ভাষা: <strong className="uppercase font-mono text-[#4F7DF7] dark:text-[#6EA8FE]">{lastOpenedProject.language}</strong>
                </span>
                <button
                  onClick={() => onSelectProject(lastOpenedProject.id)}
                  className="rounded-xl bg-[#4F7DF7]/10 hover:bg-[#4F7DF7] hover:text-white px-4 py-2 text-xs font-bold text-[#4F7DF7] dark:bg-[#6EA8FE]/10 dark:text-[#6EA8FE] dark:hover:bg-[#6EA8FE] dark:hover:text-[#090909] transition-all cursor-pointer"
                  id="continue-project-btn"
                >
                  চালিয়ে যান →
                </button>
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-4">
              <FolderOpen className="h-8 w-8 text-gray-300 dark:text-gray-700 mb-1" />
              <p className="text-xs text-gray-400 dark:text-gray-500 font-sans">কোনো সাম্প্রতিক ফাইল নেই</p>
            </div>
          )}
        </div>
      </div>

      {/* 3. Language Cards Section */}
      <div className="space-y-3" id="languages-section">
        <h3 className="text-sm font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider font-sans">ভাষা নির্বাচন করুন (Languages)</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* C Programming */}
          <div className="group relative overflow-hidden rounded-[22px] bg-white dark:bg-[#151515] p-5 shadow-[0_4px_15px_rgba(0,0,0,0.01)] border border-gray-100 dark:border-gray-800 flex flex-col justify-between min-h-[170px] hover:border-[#4F7DF7]/30 dark:hover:border-[#6EA8FE]/30 transition-all duration-300">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-500 dark:bg-blue-900/10">
                  <Code className="h-5.5 w-5.5" />
                </div>
                <span className="text-[10px] font-bold text-blue-500 bg-blue-50 dark:bg-blue-900/20 px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">C Code</span>
              </div>
              <h4 className="text-base font-bold text-gray-900 dark:text-white font-sans mt-2">সি প্রোগ্রামিং (C Language)</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-normal font-sans">
                HSC বোর্ড পরীক্ষার ৩য় ও ৫ম অধ্যায়ের মূল ভিত্তি। ধারার যোগফল, বৃহত্তম সংখ্যা এবং ফ্যাক্টোরিয়াল প্র্যাকটিস করুন।
              </p>
            </div>
            <button
              onClick={() => onCreateProject('আমার সি প্রজেক্ট', 'c', `#include <stdio.h>\n\nint main() {\n    printf("হ্যালো সি!\\n");\n    return 0;\n}`)}
              className="text-xs font-bold text-[#4F7DF7] hover:underline dark:text-[#6EA8FE] mt-4 flex items-center gap-1 cursor-pointer w-fit"
              id="lang-start-c"
            >
              <span>নতুন সি প্রজেক্ট</span>
              <span>→</span>
            </button>
          </div>

          {/* Python Programming */}
          <div className="group relative overflow-hidden rounded-[22px] bg-white dark:bg-[#151515] p-5 shadow-[0_4px_15px_rgba(0,0,0,0.01)] border border-gray-100 dark:border-gray-800 flex flex-col justify-between min-h-[170px] hover:border-yellow-500/30 transition-all duration-300">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-yellow-50 text-yellow-600 dark:bg-yellow-900/10">
                  <Terminal className="h-5.5 w-5.5" />
                </div>
                <span className="text-[10px] font-bold text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20 px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">Python 3</span>
              </div>
              <h4 className="text-base font-bold text-gray-900 dark:text-white font-sans mt-2">পাইথন প্রোগ্রামিং (Python)</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-normal font-sans">
                সহজ সিনট্যাক্স ও আধুনিক প্রোগ্রামিং ভাষা। লিপ ইয়ার, মৌলিক সংখ্যা ও গণিত সংক্রান্ত কোড প্র্যাকটিস করুন।
              </p>
            </div>
            <button
              onClick={() => onCreateProject('আমার পাইথন প্রজেক্ট', 'python', `print("হ্যালো পাইথন!")\n`)}
              className="text-xs font-bold text-yellow-600 hover:underline mt-4 flex items-center gap-1 cursor-pointer w-fit"
              id="lang-start-py"
            >
              <span>নতুন পাইথন প্রজেক্ট</span>
              <span>→</span>
            </button>
          </div>

          {/* SQLite SQL DB */}
          <div className="group relative overflow-hidden rounded-[22px] bg-white dark:bg-[#151515] p-5 shadow-[0_4px_15px_rgba(0,0,0,0.01)] border border-gray-100 dark:border-gray-800 flex flex-col justify-between min-h-[170px] hover:border-teal-500/30 transition-all duration-300">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-50 text-teal-600 dark:bg-teal-900/10">
                  <Database className="h-5.5 w-5.5" />
                </div>
                <span className="text-[10px] font-bold text-teal-600 bg-teal-50 dark:bg-teal-900/20 px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">SQLite SQL</span>
              </div>
              <h4 className="text-base font-bold text-gray-900 dark:text-white font-sans mt-2">এসকিউএল ডাটাবেজ (SQL)</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-normal font-sans">
                HSC বোর্ড পরীক্ষার ৬ষ্ঠ অধ্যায় (ডাটাবেজ)। টেবিল তৈরি, ডাটা ইনসার্ট করা এবং কুয়েরি SELECT কমান্ড রান করুন।
              </p>
            </div>
            <button
              onClick={() => onCreateProject('আমার এসকিউএল প্রজেক্ট', 'sql', `CREATE TABLE Students (\n    ID INT PRIMARY KEY,\n    Name TEXT,\n    GPA REAL\n);\n\nINSERT INTO Students VALUES (1, 'নুসরাত', 4.90);\n\nSELECT * FROM Students;`)}
              className="text-xs font-bold text-teal-600 hover:underline mt-4 flex items-center gap-1 cursor-pointer w-fit"
              id="lang-start-sql"
            >
              <span>নতুন SQL প্রজেক্ট</span>
              <span>→</span>
            </button>
          </div>

          {/* HTML / CSS / JS */}
          <div className="group relative overflow-hidden rounded-[22px] bg-white dark:bg-[#151515] p-5 shadow-[0_4px_15px_rgba(0,0,0,0.01)] border border-gray-100 dark:border-gray-800 flex flex-col justify-between min-h-[170px] hover:border-red-500/30 transition-all duration-300">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-50 text-red-500 dark:bg-red-900/10">
                  <Layers className="h-5.5 w-5.5" />
                </div>
                <span className="text-[10px] font-bold text-red-500 bg-red-50 dark:bg-red-900/20 px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">HTML5 / CSS</span>
              </div>
              <h4 className="text-base font-bold text-gray-900 dark:text-white font-sans mt-2">ওয়েব ডিজাইন (HTML)</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-normal font-sans">
                HSC বোর্ড পরীক্ষার ৪র্থ অধ্যায় (ওয়েব ডিজাইন ও HTML)। হেডিং, প্যারাগ্রাফ, টেবিল এবং ইমেজ ট্যাগ ব্যবহার করে লাইভ পেজ তৈরি করুন।
              </p>
            </div>
            <button
              onClick={() => onCreateProject('আমার ওয়েব প্রজেক্ট', 'html', `<!DOCTYPE html>\n<html>\n<head>\n    <title>কোডশালা এইচটিএমএল</title>\n</head>\n<body>\n    <h1 style="color: blue;">আমার প্রথম ওয়েব পেজ</h1>\n    <p>হ্যালো, আমি এইচটিএমএল, সিএসএস ও জাভাস্ক্রিপ্ট শিখছি!</p>\n</body>\n</html>`)}
              className="text-xs font-bold text-red-500 hover:underline mt-4 flex items-center gap-1 cursor-pointer w-fit"
              id="lang-start-html"
            >
              <span>নতুন HTML প্রজেক্ট</span>
              <span>→</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4. Projects List & Control Toolbar */}
      <div className="space-y-4 pt-2" id="project-list-section">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-gray-100 dark:border-gray-800 pb-3">
          <div className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-gray-400" />
            <h3 className="font-bold text-base text-gray-900 dark:text-white">আমার সকল প্রজেক্ট ({filteredProjects.length})</h3>
          </div>

          {/* Export full backup */}
          {projects.length > 0 && (
            <button
              onClick={handleExportBackup}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#4F7DF7] hover:underline dark:text-[#6EA8FE] cursor-pointer"
              id="export-backup-btn"
            >
              <Download className="h-3.5 w-3.5" />
              <span>অল ব্যাকআপ ডাউনলোড (JSON)</span>
            </button>
          )}
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-col sm:flex-row gap-2">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-gray-400" />
            <input
              type="text"
              placeholder="প্রজেক্টের নাম দিয়ে সার্চ করুন..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10.5 pr-4 py-3 rounded-2xl bg-white dark:bg-[#151515] border border-gray-200 dark:border-gray-800 text-sm focus:outline-none focus:border-[#4F7DF7] dark:focus:border-[#6EA8FE] transition-colors shadow-sm font-sans"
              id="project-search-input"
            />
          </div>

          {/* Quick Category Filter Pills */}
          <div className="flex gap-1 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
            {([
              { key: 'all', label: 'সব প্রজেক্ট' },
              { key: 'c', label: 'C কোড' },
              { key: 'python', label: 'Python' },
              { key: 'sql', label: 'SQL টেবিল' },
              { key: 'html', label: 'HTML ওয়েব' }
            ] as const).map(pill => (
              <button
                key={pill.key}
                onClick={() => setSelectedLanguageFilter(pill.key)}
                className={`px-4 py-3 rounded-2xl text-xs font-bold transition-all shrink-0 cursor-pointer ${selectedLanguageFilter === pill.key ? 'bg-gray-900 text-white dark:bg-white dark:text-[#090909]' : 'bg-white dark:bg-[#151515] text-gray-500 border border-gray-100 dark:border-gray-800 hover:bg-gray-50'}`}
                id={`filter-pill-${pill.key}`}
              >
                {pill.label}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Render List */}
        {filteredProjects.length === 0 ? (
          <div className="rounded-3xl bg-white dark:bg-[#151515] border border-gray-100 dark:border-gray-800 p-8 text-center flex flex-col items-center justify-center min-h-[160px]">
            <FolderOpen className="h-10 w-10 text-gray-300 dark:text-gray-700 mb-2 stroke-[1.5]" />
            <p className="text-sm font-bold text-gray-500 dark:text-gray-400 font-sans">কোনো প্রজেক্ট খুঁজে পাওয়া যায়নি</p>
            <p className="text-xs text-gray-400 dark:text-gray-600 font-sans mt-0.5">নতুন প্রজেক্ট তৈরি করে অনুশীলন শুরু করুন!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="project-cards-grid">
            {filteredProjects.map((proj) => {
              const isRenaming = renamingProjectId === proj.id;
              const isMenuOpen = activeMenuId === proj.id;

              return (
                <motion.div
                  key={proj.id}
                  layout
                  className="group relative rounded-2xl bg-white dark:bg-[#151515] p-4.5 border border-gray-100 dark:border-gray-800 shadow-[0_2px_10px_rgba(0,0,0,0.01)] hover:shadow-md transition-all flex flex-col justify-between"
                  id={`project-card-${proj.id}`}
                >
                  <div className="flex items-start justify-between">
                    {/* Title & Icon info */}
                    <div className="space-y-1.5 flex-1 pr-4">
                      {isRenaming ? (
                        <div className="flex gap-1 mt-1">
                          <input
                            type="text"
                            value={renamingName}
                            onChange={(e) => setRenamingName(e.target.value)}
                            className="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-2 py-1 text-sm focus:outline-none w-full"
                            autoFocus
                            id={`renaming-input-${proj.id}`}
                          />
                          <button
                            onClick={() => {
                              onRenameProject(proj.id, renamingName.trim());
                              setRenamingProjectId(null);
                            }}
                            className="px-2.5 bg-green-500 text-white rounded-lg text-xs font-bold"
                            id={`rename-save-btn-${proj.id}`}
                          >
                            ওকে
                          </button>
                        </div>
                      ) : (
                        <h4
                          onClick={() => onSelectProject(proj.id)}
                          className="font-bold text-gray-900 dark:text-white hover:text-[#4F7DF7] dark:hover:text-[#6EA8FE] transition-colors cursor-pointer line-clamp-1 text-sm font-sans"
                        >
                          {proj.name}
                        </h4>
                      )}

                      <div className="flex items-center gap-2">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold uppercase font-mono ${
                          proj.language === 'c' ? 'bg-blue-50 text-blue-600 dark:bg-blue-950/20' : 
                          proj.language === 'python' ? 'bg-yellow-50 text-yellow-600 dark:bg-yellow-950/20' : 
                          proj.language === 'sql' ? 'bg-teal-50 text-teal-600 dark:bg-teal-950/20' : 
                          'bg-red-50 text-red-600 dark:bg-red-950/20'
                        }`}>
                          {proj.language}
                        </span>
                        <span className="text-[10px] text-gray-400 dark:text-gray-500 font-mono">
                          {new Date(proj.updatedAt).toLocaleDateString('bn-BD')}
                        </span>
                      </div>
                    </div>

                    {/* Context menu toggle button */}
                    <div className="relative">
                      <button
                        onClick={() => setActiveMenuId(isMenuOpen ? null : proj.id)}
                        className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-700 dark:hover:text-white transition-colors"
                        id={`project-menu-trigger-${proj.id}`}
                      >
                        <MoreVertical className="h-4.5 w-4.5" />
                      </button>

                      {/* Dropdown Options */}
                      <AnimatePresence>
                        {isMenuOpen && (
                          <>
                            {/* Tap outside to close */}
                            <div className="fixed inset-0 z-10" onClick={() => setActiveMenuId(null)} />
                            <motion.div
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              exit={{ opacity: 0, scale: 0.95 }}
                              className="absolute right-0 top-8 z-20 w-44 rounded-xl border border-gray-100 bg-white p-1.5 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E] font-sans"
                              id={`project-dropdown-${proj.id}`}
                            >
                              <button
                                onClick={() => {
                                  setRenamingProjectId(proj.id);
                                  setRenamingName(proj.name);
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                                id={`menu-rename-${proj.id}`}
                              >
                                <Edit2 className="h-3.5 w-3.5 text-gray-400" />
                                <span>নাম পরিবর্তন করুন</span>
                              </button>

                              <button
                                onClick={() => {
                                  onDuplicateProject(proj.id);
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                                id={`menu-duplicate-${proj.id}`}
                              >
                                <Copy className="h-3.5 w-3.5 text-gray-400" />
                                <span>ডুপ্লিকেট প্রজেক্ট</span>
                              </button>

                              <button
                                onClick={() => {
                                  handleShareProject(proj);
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                                id={`menu-share-${proj.id}`}
                              >
                                <Share2 className="h-3.5 w-3.5 text-gray-400" />
                                <span>শেয়ার ও কপি কোড</span>
                              </button>

                              <div className="h-px bg-gray-100 dark:bg-gray-800 my-1" />

                              <button
                                onClick={() => {
                                  if (confirm(`আপনি কি "${proj.name}" প্রজেক্টটি ডিলিট করতে চান?`)) {
                                    onDeleteProject(proj.id);
                                  }
                                  setActiveMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-semibold text-red-500 hover:bg-red-50 dark:hover:bg-red-950/10 cursor-pointer"
                                id={`menu-delete-${proj.id}`}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                <span>মুছে ফেলুন</span>
                              </button>
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between border-t border-gray-50 dark:border-gray-800/50 pt-2.5">
                    <span className="text-[10px] text-gray-400 max-w-[120px] truncate font-mono">
                      {proj.code.trim().substring(0, 30)}...
                    </span>
                    <button
                      onClick={() => onSelectProject(proj.id)}
                      className="text-xs font-bold text-[#4F7DF7] dark:text-[#6EA8FE] hover:underline"
                    >
                      কোড দেখুন →
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. Create Project Modal Dialog */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreateModal(false)}
              className="absolute inset-0 bg-[#090909]"
              id="create-modal-backdrop"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-sm rounded-[24px] bg-white p-6 shadow-2xl dark:bg-[#151515] border border-gray-100 dark:border-gray-800 text-left z-10"
              id="create-modal-container"
            >
              <h3 className="text-base font-extrabold text-gray-900 dark:text-white mb-4 font-sans">নতুন লার্নিং প্রজেক্ট তৈরি করুন</h3>

              <form onSubmit={submitCreateProject} className="space-y-4 font-sans">
                {/* Input Name */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase">প্রজেক্টের নাম</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: সিরিজ যোগফল নির্ণয়"
                    value={newProjName}
                    onChange={(e) => setNewProjName(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 dark:bg-[#1E1E1E] dark:border-gray-800 rounded-xl text-sm focus:outline-none focus:border-[#4F7DF7] dark:focus:border-[#6EA8FE] text-gray-900 dark:text-white"
                    id="new-project-name-input"
                  />
                </div>

                {/* Select Language */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase">প্রোগ্রামিং ল্যাঙ্গুয়েজ</label>
                  <div className="grid grid-cols-2 gap-2">
                    {([
                      { key: 'c', label: 'C কোড', desc: 'সি প্রোগ্রামিং' },
                      { key: 'python', label: 'Python', desc: 'পাইথন ৩' },
                      { key: 'sql', label: 'SQL', desc: 'ডাটাবেজ' },
                      { key: 'html', label: 'HTML', desc: 'ওয়েব পেজ' }
                    ] as const).map(lang => (
                      <button
                        key={lang.key}
                        type="button"
                        onClick={() => setNewProjLang(lang.key)}
                        className={`flex flex-col items-center justify-center p-3.5 rounded-xl border transition-all cursor-pointer ${newProjLang === lang.key ? 'bg-[#4F7DF7]/5 text-[#4F7DF7] border-[#4F7DF7] dark:bg-[#6EA8FE]/10 dark:text-[#6EA8FE] dark:border-[#6EA8FE] font-bold' : 'bg-transparent text-gray-500 border-gray-200 dark:border-gray-800'}`}
                        id={`new-project-lang-${lang.key}`}
                      >
                        <span className="text-xs uppercase">{lang.key}</span>
                        <span className="text-[9px] text-gray-400 mt-0.5">{lang.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 rounded-xl border border-gray-200 dark:border-gray-700 py-3 text-xs font-bold text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="flex-1 rounded-xl bg-[#4F7DF7] py-3 text-xs font-bold text-white hover:bg-opacity-90 dark:bg-[#6EA8FE] dark:text-[#090909] transition-colors"
                    id="submit-create-project-btn"
                  >
                    প্রজেক্ট তৈরি করুন
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
