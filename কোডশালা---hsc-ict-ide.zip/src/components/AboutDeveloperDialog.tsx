/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Mail, Facebook, Send, Copy, Check, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AboutDeveloperDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AboutDeveloperDialog({ isOpen, onClose }: AboutDeveloperDialogProps) {
  const [copied, setCopied] = useState(false);

  const developerEmail = "mail.sahadat.official@gmail.com";

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(developerEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#090909]"
            id="dev-dialog-backdrop"
          />

          {/* Dialog Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="relative w-full max-w-md overflow-hidden rounded-[24px] bg-white p-6 shadow-2xl dark:bg-[#151515] dark:text-white border border-gray-100 dark:border-gray-800"
            id="dev-dialog-container"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 rounded-full p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-white transition-colors"
              aria-label="বন্ধ করুন"
              id="close-dialog-btn"
            >
              <X className="h-5 w-5" />
            </button>

            {/* Header / Avatar */}
            <div className="flex flex-col items-center text-center mt-2">
              <div className="relative mb-4">
                <div className="h-20 w-20 overflow-hidden rounded-full border-2 border-[#4F7DF7] dark:border-[#6EA8FE] shadow-md flex items-center justify-center bg-[#4F7DF7]/10 text-[#4F7DF7] dark:text-[#6EA8FE] font-bold text-2xl">
                  MS
                </div>
                <span className="absolute bottom-1 right-1 h-3.5 w-3.5 rounded-full border-2 border-white bg-green-500 dark:border-[#151515]" />
              </div>

              <h2 className="text-xl font-bold tracking-tight text-gray-900 dark:text-white font-sans" id="dev-name">
                মোঃ শাহাদাত হোসাইন
              </h2>
              <p className="text-sm font-medium text-[#4F7DF7] dark:text-[#6EA8FE] mt-0.5">
                প্রতিষ্ঠাতা ও সিইও, কোডশালা
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 font-mono mt-0.5">
                HSC 2027 ব্যাচ, চৌমুহনী সরকারি সালেহ আহমেদ কলেজ
              </p>
            </div>

            {/* About Biography */}
            <div className="my-5 rounded-xl bg-gray-50 p-4 dark:bg-[#1E1E1E] text-sm text-gray-600 dark:text-gray-300 leading-relaxed font-sans border border-gray-100 dark:border-gray-800">
              <p className="text-justify">
                আমি একজন তরুণ অ্যাপ ডেভেলপার ও প্রযুক্তিপ্রেমী। বর্তমানে চৌমুহনী সরকারি সালেহ আহমেদ কলেজে এইচএসসি ২০২৭ ব্যাচে পড়াশোনা করছি। আমি সহজ ও আকর্ষণীয় অ্যাপ তৈরির মাধ্যমে প্রোগ্রামিং শিক্ষাকে সবার জন্য সহজলভ্য করতে ভালোবাসি। <strong>কোডশালা</strong>-র মাধ্যমে আমার লক্ষ্য হলো বাংলাদেশের শিক্ষার্থীদের স্মার্ট, ইন্টারঅ্যাক্টিভ ও সম্পূর্ণ অফলাইন উপায়ে প্রোগ্রামিং শেখার সুযোগ করে দেওয়া।
              </p>
            </div>

            {/* Social Connect Links */}
            <div className="flex justify-center gap-4 mb-6">
              <a
                href="https://facebook.com/crazy.sahadat"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center h-10 w-10 rounded-full bg-blue-50 text-[#1877F2] hover:scale-110 active:scale-95 transition-all dark:bg-blue-900/20"
                title="ফেসবুক"
                id="social-fb"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://t.me/crazy_sahadat"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center h-10 w-10 rounded-full bg-sky-50 text-[#0088cc] hover:scale-110 active:scale-95 transition-all dark:bg-sky-900/20"
                title="টেলিগ্রাম"
                id="social-telegram"
              >
                <Send className="h-5 w-5 rotate-[-20deg] translate-x-[-1px] translate-y-[1px]" />
              </a>
              <button
                onClick={handleCopyEmail}
                className="flex items-center justify-center h-10 w-10 rounded-full bg-red-50 text-[#EA4335] hover:scale-110 active:scale-95 transition-all dark:bg-red-900/20"
                title="ইমেইল কপি করুন"
                id="social-email"
              >
                <Mail className="h-5 w-5" />
              </button>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex gap-2 font-sans">
              <button
                onClick={handleCopyEmail}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-gray-200 py-3 text-sm font-semibold text-gray-700 hover:bg-gray-50 active:scale-98 transition-all dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
                id="copy-email-btn"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4 text-green-500" />
                    <span>ইমেইল কপি হয়েছে</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    <span>ইমেইল কপি করুন</span>
                  </>
                )}
              </button>
              <button
                onClick={onClose}
                className="flex flex-1 items-center justify-center rounded-xl bg-[#4F7DF7] py-3 text-sm font-semibold text-white hover:bg-opacity-90 active:scale-98 transition-all dark:bg-[#6EA8FE] dark:text-[#090909]"
                id="close-dialog-btn"
              >
                বন্ধ করুন
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
